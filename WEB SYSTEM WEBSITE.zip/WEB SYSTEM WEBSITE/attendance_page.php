
<!DOCTYPE html>
<html>
<head>
 <title>attendance page</title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet"href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>


     <link rel="stylesheet" href="css/newstyle.css">
</head>
<body>


</div>
</div>
<?php
@include 'config.php';
$select = "SELECT * FROM navbar";
$selected = $con->query($select);
if ($selected->num_rows > 0) {
while ($row = $selected->fetch_assoc()) {
?>

<div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel"style="box-shadow: 15px 15px 40px rgba(0, 0, 0, 0.5) ;">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="new.jpg" class="d-block w-100" style="height:150px;" alt="...">
    </div>
  </div>
</div>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid"style="box-shadow: 15px 15px 40px rgba(0, 0, 0, 0.5) ;">
    <a class="navbar-brand" href="#">SLU</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
        <td><a href="home_page.php"><?php echo $row['home']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="about_page.php"><?php echo $row['about']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="attendance_page.php"><?php echo $row['attendance']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="record_attendance_page.php"><?php echo $row['profife']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="profile_page.php"><?php echo $row['new']; ?></a></td>
        </li>
        
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-white"  id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Output
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item"  href="login_form.php">login</a></li>
            <li><a class="dropdown-item" href="index.php">Register</a></li>
            <li><a class="dropdown-item" href="logout.php">logout</a></li>
</ul>
       </li>
      </ul>
    </div>
  </div>
</nav>
<?php
}}
?>

<?php
    include "config.php";
    if(isset($_POST['submit'])){
        $fullname = $_POST['fullname'];
        $course = $_POST['course'];
        $year = $_POST['year'];
        $block = $_POST['block'];
       

        $q = " INSERT INTO `attendance_tbl`(`fullname`, `course`,`year`,`block`) VALUES ( '$fullname', '$course','$year','$block' )";

        $query = mysqli_query($con,$q);
    }
    ?>

<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-lg-6">
      <div class="card p-3 mb-5"style="box-shadow: 15px 15px 40px rgba(0, 0, 0, 0.5) ;">
        <div class="card-header text-white" style="background:#333">
          <h1 class="text-center">Attendance Here</h1>
        </div>
        <div class="card-body">
          <form method="post" action="add_attendance.php">
            <div class="mb-3">
              <label for="fullname" class="form-label">Full Name:</label>
              <input type="text" name="fullname" class="form-control" required>
            </div>
            <div class="mb-3">
              <label for="course" class="form-label">Course:</label>
              <input type="text" name="course" class="form-control" required>
            </div>
            <div class="mb-3">
              <label for="year" class="form-label">Year:</label>
              <input type="text" name="year" class="form-control" required>
            </div>
            <div class="mb-3">
              <label for="block" class="form-label">Block:</label>
              <input type="text" name="block" class="form-control" required>
            </div>
            <div class="mb-3">
              <label for="address" class="form-label">Address:</label>
              <input type="text" name="address" class="form-control" required>
            </div>
            <div class="mb-3">
              <label for="email" class="form-label">Email:</label>
              <input type="email" name="email" class="form-control" required>
            </div>
            <div class="mb-3">
              <label for="contact_number" class="form-label">Contact Number:</label>
              <input type="text" name="contact_number" class="form-control" required>
            </div>
            <div class="mb-3">
            <button type="submit" name="submit" class="btn btn-success">Submit</button>
            </div>
            <div class="mb-1">
            <a class="btn btn-warning" href="user_attendance_page.php">Cancel</a>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js"></script>

</body>
</html>