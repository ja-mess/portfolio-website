<?php 
$server = 'localhost';
$username = 'root';
$password = '';
$databasename = 'system_db';
$con = new mysqli($server, $username, $password, $databasename);
?>
