<?php
@include 'config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Update the user status to "Deactivated" in the database
    $sql = "UPDATE login_tbl SET user_type = 'Deactivated' WHERE id = '$id'";
    $result = mysqli_query($con, $sql);
    
    if ($result) {
        // Deactivation successful
        echo '<script>alert("User deactivated successfully!");</script>';
    } else {
        // Deactivation failed
        echo '<script>alert("Failed to deactivate user. Please try again.");</script>';
    }
    
    // Redirect back to the dashboard page
    echo '<script>window.location.href = "dashboard_page.php";</script>';
} else {
    // If user ID is not provided, redirect back to the dashboard page
    header("Location: dashboard_page.php");
    exit();
}
?>
