
<?php
    include "config.php";
    if(isset($_GET['id'])){
      
        $id = $_GET['id'];
        $sql = "DELETE from `login_tbl` where id=$id";
        $con->query($sql);
       
    }
    header('location:dashboard_page.php');
    exit;
?>