<?php
@include 'config.php';
$update = "DELETE FROM `homepage_tbl`  WHERE id= '".$_GET['id']."'  ";
$updated = $con->query($update);
if ($updated == true){
  ?>
  <script>
    alert("data updated");
    window.location = "home_page.php";
  </script>
  <?php
}