-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2024 at 12:58 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `system_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `aboutpage_tbl`
--

CREATE TABLE `aboutpage_tbl` (
  `id` int(11) NOT NULL,
  `firstname` longtext NOT NULL,
  `profilepicture` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `aboutpage_tbl`
--

INSERT INTO `aboutpage_tbl` (`id`, `firstname`, `profilepicture`) VALUES
(13, 'Vision Mission Objectives Vision/Mission The Saint Louis University Libraries envision themselves as a support service to the transformative educational process of SLU and are committed to providing expedient and effective access to high quality library services, collections in a variety of formats and information resources designed to meet the curriculum, research, professional, intellectual, creative and personal needs of the SLU community.', '6627771685516.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `attendance_tbl`
--

CREATE TABLE `attendance_tbl` (
  `id` int(255) NOT NULL,
  `fullname` varchar(250) DEFAULT NULL,
  `course` varchar(250) DEFAULT NULL,
  `year` varchar(250) DEFAULT NULL,
  `block` varchar(250) DEFAULT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `join_date` date NOT NULL DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance_tbl`
--

INSERT INTO `attendance_tbl` (`id`, `fullname`, `course`, `year`, `block`, `address`, `email`, `contact_number`, `join_date`) VALUES
(2, 'Kyla Asumio', 'BSIT', '2', 'D', 'lsahbf', 'ky@gmail.com', '91245237482', '2024-05-06'),
(3, 'Kyla Asumio', 'BSIT', '1', 'r', 'lsahbf', 'ky@gmail.com', '122534636', '2024-05-07'),
(4, 'Kyla Asumio', 'BSIT', '1', 'r', 'lsahbf', 'ky@gmail.com', '122534636', '2024-05-07'),
(5, 'Kyla Asumio', 'BSIT', '1', 'r', 'lsahbf', 'ky@gmail.com', '122534636', '2024-05-07'),
(6, 'Kyla Asumio', 'BSIT', '1', 'r', 'lsahbf', 'ky@gmail.com', '91245237482', '2024-05-07'),
(7, 'Kyla Asumio', 'BSIT', '1', 'r', 'lsahbf', 'ky@gmail.com', '122534636', '2024-05-07'),
(8, 'Kyla Asumio', 'BSIT', '1', 'r', 'lsahbf', 'ky@gmail.com', '122534636', '2024-05-07'),
(9, 'Kyla Asumio', 'BSIT', '1', 'r', 'lsahbf', 'ky@gmail.com', '122534636', '2024-05-07');

-- --------------------------------------------------------

--
-- Table structure for table `homepage_tbl`
--

CREATE TABLE `homepage_tbl` (
  `id` int(11) NOT NULL,
  `firstname` longtext NOT NULL,
  `profilepicture` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `homepage_tbl`
--

INSERT INTO `homepage_tbl` (`id`, `firstname`, `profilepicture`) VALUES
(12, 'Certainly! The Commission on Higher Education (CHED) issued a memorandum regarding the suspension of the implementation of CHED Memorandum Order (CMO) No. 22, Series of 2003. According to this memorandum, the “Revised Guidelines in Processing Request for Issuance of CHED Endorsement to Hold An Activity” ', '66277175f0d9a.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `login_tbl`
--

CREATE TABLE `login_tbl` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `navbar`
--

CREATE TABLE `navbar` (
  `id` int(11) NOT NULL,
  `home` varchar(255) NOT NULL,
  `about` varchar(255) NOT NULL,
  `attendance` varchar(255) NOT NULL,
  `profife` varchar(255) NOT NULL,
  `new` varchar(255) NOT NULL,
  `db` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `navbar`
--

INSERT INTO `navbar` (`id`, `home`, `about`, `attendance`, `profife`, `new`, `db`) VALUES
(1, 'HOME', 'ABOUT', 'ATTENDANCE', 'RECORDS', 'PROFILE', 'DASHBOARD');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aboutpage_tbl`
--
ALTER TABLE `aboutpage_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance_tbl`
--
ALTER TABLE `attendance_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `homepage_tbl`
--
ALTER TABLE `homepage_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_tbl`
--
ALTER TABLE `login_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `navbar`
--
ALTER TABLE `navbar`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aboutpage_tbl`
--
ALTER TABLE `aboutpage_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `attendance_tbl`
--
ALTER TABLE `attendance_tbl`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `homepage_tbl`
--
ALTER TABLE `homepage_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `login_tbl`
--
ALTER TABLE `login_tbl`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `navbar`
--
ALTER TABLE `navbar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
