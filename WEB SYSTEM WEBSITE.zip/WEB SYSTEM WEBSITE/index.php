

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>register form</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="style.css">
   <script src="
https://cdn.jsdelivr.net/npm/sweetalert2@11.10.8/dist/sweetalert2.all.min.js
"></script>
<link href="
https://cdn.jsdelivr.net/npm/sweetalert2@11.10.8/dist/sweetalert2.min.css
" rel="stylesheet">
<link rel="stylesheet"href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>


</head>
<body>
<?php

@include 'config.php';

if(isset($_POST['submit'])){

   $name = mysqli_real_escape_string($con, $_POST['name']);
   $email = $_POST['email'];
   $pass = md5($_POST['password']);
   $cpass = md5($_POST['cpassword']);
   $user_type = $_POST['user_type'];

   $select = " SELECT * FROM login_tbl WHERE email = '$email' && password = '$pass' ";

   $result = mysqli_query($con, $select);

   if(mysqli_num_rows($result) > 0){

      $error[] = 'user already exist!';
      ?>
      <script>
       Swal.fire({
          icon: "error",
          title: "Oops...",
          text: "Something went wrong!",
          confirmButtonText: 'OK'
        });
        </script>
        <?php

   }else{

      if($pass != $cpass){
         $error[] = 'password not matched!';
         ?>
         <script>
          Swal.fire({
             icon: "error",
             title: "Oops...",
             text: "Something went wrong!",
             confirmButtonText: 'OK'
           });
           </script>
           <?php
      }else{
         $insert = "INSERT INTO login_tbl(name, email, password, user_type) VALUES('$name','$email','$pass','$user_type')";
         mysqli_query($con, $insert);
         ?>
         <script>
            Swal.fire({
               icon: "success",
               title: "Success!",
               text: "Registration Successful.",
               confirmButtonText: 'OK'
             });
             </script>
             <?php
         header('location:login_form.php');
     
      }
   }

};


?>
<div class="container">
    <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: -1;">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="2.jpg" class="d-block w-100" style="height: 100%; object-fit: cover;" alt="Slide 1">
            </div>
            <div class="carousel-item">
                <img src="3.jpg" class="d-block w-100" style="height: 100%; object-fit: cover;" alt="Slide 2">
            </div>
            <div class="carousel-item">
                <img src="4.jpg" class="d-block w-100" style="height: 100%; object-fit: cover;" alt="Slide 3">
            </div>
        </div>
    </div>

    <div class="row justify-content-center align-items-center" style="height: 100vh;">
        <div class="col-md-6">
            <div class="form-container bg-secondary p-4" style="box-shadow: 15px 15px 40px rgba(0, 0, 0, 0.5);">
                <div class="card p-4">
                    <form action="" method="post">
                        <h3 class="text-center bg-dark p-3 text-white mb-4"style="border-radius:5px">Register Now</h3>
                        <?php
                        if(isset($error)){
                            foreach($error as $error){
                                echo '<span class="error-msg">'.$error.'</span>';
                            };
                        };
                        ?>
                        <div class="mb-3">
                            <input type="text" name="name" required placeholder="Enter your name" class="form-control">
                        </div>
                        <div class="mb-3">
                            <input type="email" name="email" required placeholder="Enter your email" class="form-control">
                        </div>
                        <div class="mb-3">
                            <input type="password" name="password" required placeholder="Enter your password" class="form-control">
                        </div>
                        <div class="mb-3">
                            <input type="password" name="cpassword" required placeholder="Confirm your password" class="form-control">
                        </div>
                        <div class="mb-3">
                            <select name="user_type" class="form-control">
                                <option value="user">User</option>
                                <option value="admin">Admin</option>
                                <option value="super_admin">Super Admin</option>
                            </select>
                        </div>
                        <div class="mb-3 p-3">
                            <input type="submit" name="submit" value="Register Now" class="btn btn-dark form-control">
                        </div>
                        <p class="text-center mb-0">Already have an account? <a href="login_form.php" style="color:red;">Login now</a></p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


</body>
</html>