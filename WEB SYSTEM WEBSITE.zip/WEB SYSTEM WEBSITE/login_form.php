



<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>login form</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="">
   <script src="
https://cdn.jsdelivr.net/npm/sweetalert2@11.10.8/dist/sweetalert2.all.min.js
"></script>
<link href="
https://cdn.jsdelivr.net/npm/sweetalert2@11.10.8/dist/sweetalert2.min.css
" rel="stylesheet">
<link rel="stylesheet"href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>


</head>
<body>
   <style>
 
   </style>
<?php

@include 'config.php';

session_start();

if(isset($_POST['submit'])){

   
  
   $email = $_POST['email'];
   $select = " SELECT * FROM login_tbl WHERE email = '$email' ";

   $result = mysqli_query($con, $select);

   if(mysqli_num_rows($result) > 0){

      $row = mysqli_fetch_array($result);
 
     
       
      if($row['user_type'] == 'admin' ){

         $_SESSION['admin_id'] = $row['id'];
         $_SESSION['admin_name'] = $row['name'];
         $_SESSION['admin_email'] = $row['email'];
         $_SESSION['admin_password'] = $row['password'];

         header('location:home_page.php');
        

      }elseif($row['user_type'] == 'user'){
       

         $_SESSION['user_id'] = $row['id'];
         $_SESSION['user_name'] = $row['name'];
         $_SESSION['user_email'] = $row['email'];
         $_SESSION['user_password'] = $row['password'];
         
         
         header('location:user_home_page.php');
        

      }elseif($row['user_type'] == 'super_admin'){
       

         $_SESSION['super_admin_id'] = $row['id'];
         $_SESSION['super_admin_name'] = $row['name'];
         $_SESSION['super_admin_email'] = $row['email'];
         $_SESSION['super_admin_password'] = $row['password'];
         
         
         header('location:super_home_page.php');
        

      }
     
   }else{
      $error[] = 'incorrect email or password!';
      ?>
     <script>
      Swal.fire({
         icon: "error",
         title: "Oops...",
         text: "Something went wrong!",
         footer: '<a href="#">Why do I have this issue?</a>'
       });
       </script>
       <?php
     
   }

};
?>
<div class="container">
    <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: -1;">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="2.jpg" class="d-block w-100" style="height: 100%; object-fit: cover; border-radius: 10px;" alt="Slide 1">
            </div>
            <div class="carousel-item">
                <img src="3.jpg" class="d-block w-100" style="height: 100%; object-fit: cover; border-radius: 10px;" alt="Slide 2">
            </div>
            <div class="carousel-item">
                <img src="4.jpg" class="d-block w-100" style="height: 100%; object-fit: cover; border-radius: 10px;" alt="Slide 3">
            </div>
        </div>
    </div>

    <div class="row justify-content-center align-items-center" style="height: 100vh;">
        <div class="col-md-6">
            <div class="form-container bg-secondary p-4" style="box-shadow: 15px 15px 40px rgba(0, 0, 0, 0.5);">
                <div class="card p-4">
                    <form action="" method="post">
                    <h3 class="text-center bg-dark p-3 text-white mb-4" style="border-radius:5px">Login Now</h3>
                        <?php
                        if(isset($error)){
                            foreach($error as $error){
                                echo '<span class="error-msg">'.$error.'</span>';
                            };
                        };
                        ?>
                        <div class="mb-3">
                            <input type="email" name="email" required placeholder="Enter your email" class="form-control">
                        </div>
                        <div class="mb-3">
                            <input type="password" name="password" required placeholder="Enter your password" class="form-control">
                        </div>
                        <div class="mb-3">
                            <input type="submit" name="submit" value="Login Now" class="btn btn-dark form-control">
                        </div>
                        <p class="text-center mb-0">Don't have an account? <a href="index.php" style="color:red;">Register now</a></p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>