<?php

@include 'config.php';

session_start();
session_unset();
session_destroy();
?>
<script>
   Swal.fire({
      icon: "success",
      title: "Success!",
      text: "Login Successful.",
      confirmButtonText: 'OK'
    });
    </script>
    <?php

header('location:login_form.php');

?>