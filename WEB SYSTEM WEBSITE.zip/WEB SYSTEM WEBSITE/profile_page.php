<?php

@include 'config.php';

session_start();



?>




<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet"href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
  <script src="
https://cdn.jsdelivr.net/npm/sweetalert2@11.10.8/dist/sweetalert2.all.min.js
"></script>
<link href="
https://cdn.jsdelivr.net/npm/sweetalert2@11.10.8/dist/sweetalert2.min.css
" rel="stylesheet">

  <!-- custom css file link  -->
     <link rel="stylesheet" href="css/newstyle.css">

    <title>Record Attendance</title>
  </head>
  <body>

<div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel"style="box-shadow: 15px 15px 40px rgba(0, 0, 0, 0.5) ;">
  <div class="carousel-inner">
    <div class="carousel-item active">
    <img src="new.jpg" style="height:150px;width:100vw;" alt="...">
</div>
  </div>
  </div>
 
</div>
</div>
  <?php
@include 'config.php';
$select = "SELECT * FROM navbar";
$selected = $con->query($select);
if ($selected->num_rows > 0) {
while ($row = $selected->fetch_assoc()) {
?>
<nav class="navbar navbar-expand-lg navbar-light  ">
  <div class="container-fluid"style="box-shadow: 15px 15px 40px rgba(0, 0, 0, 0.5) ;">
    <a class="navbar-brand" href="#">SLU</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
        <td><a href="home_page.php"><?php echo $row['home']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="about_page.php"><?php echo $row['about']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="attendance_page.php"><?php echo $row['attendance']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="record_attendance_page.php"><?php echo $row['profife']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="profile_page.php"><?php echo $row['new']; ?></a></td>
        </li>
        
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-white"  id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Output
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item"  href="login_form.php">login</a></li>
            <li><a class="dropdown-item" href="index.php">Register</a></li>
            <li><a class="dropdown-item" href="logout.php">logout</a></li>
</ul>
       </li>
      </ul>
    </div>
  </div>
</nav>
<?php
}}
?>

    
    <div id="searchresult"></div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <div class="container my-4">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card" style="box-shadow: 15px 15px 40px rgba(0, 0, 0, 0.5); margin-bottom: 30px;">
                <div class="card-body">
                    <h1 class="text-center">Profile Page</h1>

<div class="table-responsive">
    <table class="table table-boardred table-hover table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>NAME</th>
                <th>EMAIL</th>
                <th>PASSWORD</th>
                <th>ACTIONS</th>
            </tr>
        </thead>
        <tbody>
            <?php
            include "config.php";
            $sql = "SELECT * FROM login_tbl WHERE id = $_SESSION[admin_id]";
            $result = $con->query($sql);
            if(!$result){
                die("Invalid query!");
            }
            while($row = $result->fetch_assoc()){
                echo "
                <tr>
                    <td>{$row['id']}</td>
                    <td>{$row['name']}</td>
                    <td>{$row['email']}</td>
                    <td>{$row['password']}</td>
                    <td>
                        <a class='btn-ed btn-success btn-sm' href='update_profile_page.php?id={$row['id']}'>Edit</a>
                    </td>
                </tr>";
            }
            ?>
        </tbody>
    </table>
    </div>
            </div>
        </div>
    </div>
</div>


    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>

         



   
       
    </thead>


</body>
</html>