<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet"href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
  <script src="
https://cdn.jsdelivr.net/npm/sweetalert2@11.10.8/dist/sweetalert2.all.min.js
"></script>
<link href="
https://cdn.jsdelivr.net/npm/sweetalert2@11.10.8/dist/sweetalert2.min.css
" rel="stylesheet">

  <!-- custom css file link  -->
     <link rel="stylesheet" href="css/newstyle.css">

    <title>Record Attendance</title>
  </head>
  <body>
<style>
  td{
    color:#333
  }
</style>
<div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
    <img src="new.jpg" style="height:150px;width:100vw;" alt="...">
</div>
  </div>
  </div>
 
</div>
</div>
  <?php
@include 'config.php';
$select = "SELECT * FROM navbar";
$selected = $con->query($select);
if ($selected->num_rows > 0) {
while ($row = $selected->fetch_assoc()) {
?>
<nav class="navbar navbar-expand-lg navbar-light  ">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">SLU</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
        <td><a href="home_page.php"><?php echo $row['home']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="about_page.php"><?php echo $row['about']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="attendance_page.php"><?php echo $row['attendance']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="record_attendance_page.php"><?php echo $row['profife']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="profile_page.php"><?php echo $row['new']; ?></a></td>
        </li>
        
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-white"  id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Output
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item"  href="login_form.php">login</a></li>
            <li><a class="dropdown-item" href="index.php">Register</a></li>
            <li><a class="dropdown-item" href="logout.php">logout</a></li>
          </ul>
       </li>
      </ul>
    </div>
  </div>
</nav>
<?php
}}
?>

    

<?php
include 'config.php';

// Number of records per page
$records_per_page = isset($_GET['records']) ? $_GET['records'] : 10;

// Sorting parameters
$sort_column = isset($_GET['sort']) ? $_GET['sort'] : 'id';
$sort_order = isset($_GET['order']) ? $_GET['order'] : 'ASC';

// Pagination
$current_page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($current_page - 1) * $records_per_page;

// Fetch records with sorting and pagination
$select_query = "SELECT * FROM attendance_tbl ORDER BY $sort_column $sort_order LIMIT $offset, $records_per_page";
$result = $con->query($select_query);

?>

<div class="container mt-1 p-4" style="background:#333;">
    <h1 class="text-center p-2 bg-white" style="border-radius:5px">ATTENDANCE RECORDS</h1>
    <div class="table-responsive text-white">
        <form action="" method="get">
            Show
            <select name="records">
                <option value="10" <?php if ($records_per_page == 10) echo 'selected'; ?>>10</option>
                <option value="20" <?php if ($records_per_page == 20) echo 'selected'; ?>>20</option>
                <option value="30" <?php if ($records_per_page == 30) echo 'selected'; ?>>30</option>
                <option value="40" <?php if ($records_per_page == 40) echo 'selected'; ?>>40</option>
                <option value="50" <?php if ($records_per_page == 50) echo 'selected'; ?>>50</option>
            </select>
        
            <input type="submit" value="Apply">
        </form>
     
        <table class="table p-5 table-bordered table-hover text-white table-striped" id="studtable" name="studtable"
            style="background-color:lightgrey;color:white;">
            <thead>
            <button  id="printBtn">Print</button>
                <tr>
                    <th class="text-center text-dark"><a href="?sort=id&order=<?php echo ($sort_column == 'id' && $sort_order == 'ASC') ? 'DESC' : 'ASC'; ?>">ID</a></th>
                    <th class="text-center text-dark"><a href="?sort=fullname&order=<?php echo ($sort_column == 'fullname' && $sort_order == 'ASC') ? 'DESC' : 'ASC'; ?>">Name</a></th>
                    <th class="text-center text-dark">COURSE</th>
                    <th class="text-center text-dark">YEAR</th>
                    <th class="text-center text-dark">BLOCK</th>
                    <th class="text-center text-dark">ADDRESS</th>
                    <th class="text-center text-dark">EMAIL</th>
                    <th class="text-center text-dark">CONTACT NUMBER</th>
                    <th class="text-center text-dark">JOIN DATE</th>
                    <th class="text-center text-dark">ACTION</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                ?>
                        <tr>
                            <td><?php echo $row["id"] ?></td>
                            <td><?php echo $row["fullname"] ?></td>
                            <td><?php echo $row["course"] ?></td>
                            <td><?php echo $row["year"] ?></td>
                            <td><?php echo $row["block"] ?></td>
                            <td><?php echo $row["address"] ?></td>
                            <td><?php echo $row["email"] ?></td>
                            <td><?php echo $row["contact_number"] ?></td>
                            <td><?php echo $row["join_date"] ?></td>
                            <td>
                                <a class='btn-ed btn-success btn-sm' href='update_record_attendance_page.php?id=<?php echo $row['id'] ?>'>Edit</a>
                                <a class='btn-del btn-danger btn-sm' href='delete_record_attendance_page.php?id=<?php echo $row['id'] ?>'>Delete</a>
                            </td>
                        </tr>
                <?php
                    }
                } else {
                    echo "<tr><td colspan='10'> No data found </td></tr>";
                }
                ?>
            </tbody>
        </table>
        <?php
        // Pagination links
        $total_records_query = "SELECT COUNT(*) AS total_records FROM attendance_tbl";
        $total_records_result = $con->query($total_records_query);
        $total_records = $total_records_result->fetch_assoc()['total_records'];
        $total_pages = ceil($total_records / $records_per_page);

        echo "<ul class='pagination'>";
        for ($i = 1; $i <= $total_pages; $i++) {
            echo "<li class='page-item'><a class='page-link' href='?page=$i&records=$records_per_page&sort=$sort_column&order=$sort_order'>$i</a></li>";
        }
        echo "</ul>";
        ?>
    </div>
</div>


<script src= "jquery-3.7.1.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.1.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.1.1/js/buttons.html5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<script>
$(document).ready(function() {
  // Initialize DataTable
  $('#studtable').DataTable({
    dom: 'Bfrtip',
    buttons: [
      'copyHtml5',
      'csvHtml5',
      'pdfHtml5',
      'print'
    ]
  });

  // Handle export button click
  $('.export-btn').on('click', function() {
    // Trigger PDF export
    $('#studtable').DataTable().button('.buttons-pdf').trigger();
  });
});
</script>


  
        <script src= "sweetalert2.all.min.js"></script>
        <script>
            $('.btn-del').on('click', function(e){
                e.preventDefault();
                const href =$(this).attr('href')

                Swal.fire({
                    title : 'Are you Sure?',
                    text: 'Record will be deleted',
                    type : 'warning',
                    icon : 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ok'
                }).then ((result) => {
                    if (result.value) {
                        document.location.href = href;
                    }
                })
            })
        </script>

    
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>