
<?php
    include "config.php";
    if(isset($_GET['id'])){
      
        $id = $_GET['id'];
        $sql = "DELETE from `attendance_tbl` where id=$id";
        $con->query($sql);
       
    }
    header('location: super_record_attendance_page.php');
    exit;
?>