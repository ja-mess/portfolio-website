<?php
@include 'config.php';
$update = "DELETE FROM `aboutpage_tbl`  WHERE id= '".$_GET['id']."'  ";
$updated = $con->query($update);
if ($updated == true){
  ?>
  <script>
    alert("data updated");
    window.location = "super_about_page.php";
  </script>
  <?php
}