
<?php 
@include "config.php";
$email = $_POST['email'];
$pass = md5($_POST['password']);
$update = "UPDATE login_tbl SET email = '$email' , password = '$pass' WHERE id='".$_GET['id']."' ";
$updated = $con->query($update);
if ($updated == true) {
?>
<script type="text/javascript">
alert("Data Updated");
window.location="super_profile_page.php";
</script>
<?php 
}
?>