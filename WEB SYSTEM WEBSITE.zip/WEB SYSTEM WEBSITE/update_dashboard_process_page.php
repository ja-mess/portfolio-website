
<?php 
@include "config.php";
$name = $_POST['name'];
$email = $_POST['email'];
$pass = md5($_POST['password']);
$user = $_POST['user_type'];
$update = "UPDATE login_tbl SET name = '$name' , email = '$email' , password = '$pass' ,user_type = '$user'WHERE id='".$_GET['id']."' ";
$updated = $con->query($update);
if ($updated == true) {
?>
<script type="text/javascript">
alert("Data Updated");
window.location="dashboard_page.php";
</script>
<?php 
}
?>