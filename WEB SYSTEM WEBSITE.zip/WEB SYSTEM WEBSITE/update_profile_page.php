<?php
 @include 'config.php';
 $select = "SELECT * FROM login_tbl WHERE id='".$_GET['id']."' ";
 $selected = $con->query($select);
$fetch = mysqli_fetch_assoc($selected);

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet"href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
  <script src="
https://cdn.jsdelivr.net/npm/sweetalert2@11.10.8/dist/sweetalert2.all.min.js
"></script>
<link href="
https://cdn.jsdelivr.net/npm/sweetalert2@11.10.8/dist/sweetalert2.min.css
" rel="stylesheet">

  <!-- custom css file link  -->
  <link rel="stylesheet" href="css/newstyle.css">



   <title>Document</title>
</head>
<body>

<style>
    label{
      font-size:20px;

    }
    H3{
      text-align:center;
    }
    a {

      text-align:center;   
    }
    p{
      font-size:17px;
    }
    input{
      border-radius:8px;
    }
   </style>
<div class="container">
   <div class="row justify-content-center">
      <div class="col-lg-12">
         <div class="card" style="padding: 30px; box-shadow: 15px 15px 40px rgba(0, 0, 0, 0.5);">
            <?php
               @include 'config.php';
               $select = "SELECT * FROM login_tbl WHERE id='".$_GET['id']."'";
               $selected = $con->query($select);
               $row = mysqli_fetch_assoc($selected);
               ?>
            <form action="update_profile_page_process.php?id=<?php echo $_GET['id']; ?>" method="post">
               <h3 class="text-center">PROFILE</h3>
               <div class="mb-3">
                  <label class="form-label">Name:</label>
                  <input type="text" class="form-control" name="name" value="<?php echo $row['name']; ?>">
               </div>
               <div class="mb-3">
                  <label class="form-label">Email:</label>
                  <input type="text" class="form-control" name="email" value="<?php echo $row['email']; ?>">
               </div>
               <div class="mb-3">
                  <label class="form-label">Password:</label>
                  <input type="text" class="form-control" name="password" value="<?php echo $row['password']; ?>">
               </div>
               <div class="text-center">
                  <input type="submit" class="btn btn-primary" value="Update">
                  <a href="profile_page.php" class="btn btn-secondary">Cancel</a>
               </div>
            </form>
         </div>
      </div>
   </div>
</div>

   
</body>
</html>
