
<?php 
@include "config.php";
$name = mysqli_real_escape_string($con, $_POST['name']);
$email = $_POST['email'];
$pass = md5($_POST['password']);
$update = "UPDATE login_tbl SET name= '$name',email = '$email' , password = '$pass' WHERE id='".$_GET['id']."' ";
$updated = $con->query($update);
if ($updated == true) {
?>
<script type="text/javascript">
alert("Data Updated");
window.location="profile_page.php";
</script>
<?php 
}
?>