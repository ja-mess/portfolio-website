
<!DOCTYPE html>
<html>
<head>
 <title>CRUD</title>

 <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet"href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
     <!-- custom css file link  -->
     <link rel="stylesheet" href="css/newstyle.css">
</head>
<body>

<div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
    <img src="new.jpg" style="height:150px;width:100vw;" alt="...">
</div>
  </div>
  </div>
 
</div>
</div>
<?php
@include 'config.php';
$select = "SELECT * FROM navbar";
$selected = $con->query($select);
if ($selected->num_rows > 0) {
while ($row = $selected->fetch_assoc()) {
?>
<nav class="navbar navbar-expand-lg navbar-light  ">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">SLU</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
        <td><a href="home_page.php"><?php echo $row['home']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="about_page.php"><?php echo $row['about']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="attendance_page.php"><?php echo $row['attendance']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="record_attendance_page.php"><?php echo $row['profife']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="profile_page.php"><?php echo $row['new']; ?></a></td>
        </li>
        
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-white"  id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Output
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item"  href="login_form.php">login</a></li>
            <li><a class="dropdown-item" href="index.php">Register</a></li>
            <li><a class="dropdown-item" href="logout.php">logout</a></li>
</ul>
       </li>
      </ul>
    </div>
  </div>
</nav>
<?php
}}
?>
</head>
<body>

<?php
include "config.php";

$id = "";
$fullname = "";
$course = "";
$year = "";
$block = "";
$address = "";
$email = "";
$contact_number = "";

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == 'GET') {
    if (!isset($_GET['id'])) {
        header("location:crud100/record_attendance_page.php");
        exit;
    }
    $id = $_GET['id'];
    $sql = "SELECT * FROM attendance_tbl WHERE id=$id";
    $result = $con->query($sql);
    $row = $result->fetch_assoc();
    while (!$row) {
        header("location: crud100/record_attendance_page.php");
        exit;
    }
    $fullname = $row["fullname"];
    $course = $row["course"];
    $year = $row["year"];
    $block = $row["block"];
    $address = $row["address"];
    $email = $row["email"];
    $contact_number = $row["contact_number"];
} else {
    $id = $_POST["id"];
    $fullname = $_POST["fullname"];
    $course = $_POST["course"];
    $year = $_POST["year"];
    $block = $_POST["block"];
    $address = $_POST["address"];
    $email = $_POST["email"];
    $contact_number = $_POST["contact_number"];

    $sql = "UPDATE attendance_tbl SET fullname='$fullname', course='$course', year='$year', block='$block', address='$address', email='$email', contact_number='$contact_number' WHERE id='$id'";
    $result = $con->query($sql);
    ?>
    <script>
    alert("Data updated");
    window.location = "record_attendance_page.php";
  </script>
    <?php
}

?>
<div class="col-lg-6 m-auto">
    <form method="post">
        <br><br>
        <div class="card" style="padding:15px">
            <div class="card" style="background-color:#333;">
                <h1 class="text-white text-center">  Update Student </h1>
            </div><br>

            <input type="hidden" name="id" value="<?php echo $id; ?>" class="form-control"> <br>

            <label> NAME: </label>
            <input type="text" name="fullname" value="<?php echo $fullname; ?>" class="form-control"> <br>

            <label> COURSE: </label>
            <input type="text" name="course" value="<?php echo $course; ?>" class="form-control"> <br>

            <label> YEAR: </label>
            <input type="text" name="year" value="<?php echo $year; ?>" class="form-control"> <br>

            <label> BLOCK: </label>
            <input type="text" name="block" value="<?php echo $block; ?>" class="form-control"> <br>

            <label> ADDRESS: </label>
            <input type="text" name="address" value="<?php echo $address; ?>" class="form-control"> <br>

            <label> EMAIL: </label>
            <input type="email" name="email" value="<?php echo $email; ?>" class="form-control"> <br>

            <label> CONTACT NUMBER: </label>
            <input type="text" name="contact_number" value="<?php echo $contact_number; ?>" class="form-control"> <br>

            <button class="btn btn-success m-3" type="submit" name="submit"> Submit</button><br>
            <a class="btn btn-warning" type="submit" name="cancel" href="record_attendance_page.php" style="margin:15px"> Cancel </a><br>

        </div>
    </form>
</div>

</body>
</html>
