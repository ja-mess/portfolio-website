<?php
 @include 'config.php';
 $select = "SELECT * FROM homepage_tbl WHERE id='".$_GET['id']."' ";
 $selected = $con->query($select);
$fetch = mysqli_fetch_assoc($selected);

?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet"href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>

   <title>UPDATE page</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/newstyle.css">

</head>
<body>
<div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel"style="box-shadow: 15px 15px 40px rgba(0, 0, 0, 0.5) ; ">
  <div class="carousel-inner">
    <div class="carousel-item active">
    <img src="new.jpg" style="height:150px;width:100vw;" alt="...">
</div>
  </div>
  </div>
 
</div>
</div>
<?php
@include 'config.php';
$select = "SELECT * FROM navbar";
$selected = $con->query($select);
if ($selected->num_rows > 0) {
while ($row = $selected->fetch_assoc()) {
?>
<nav class="navbar navbar-expand-lg navbar-light  ">
  <div class="container-fluid" style="box-shadow: 15px 15px 40px rgba(0, 0, 0, 0.5) ; ">
    <a class="navbar-brand" href="#">SLU</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
        <td><a href="home_page.php"><?php echo $row['home']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="about_page.php"><?php echo $row['about']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="attendance_page.php"><?php echo $row['attendance']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="record_attendance_page.php"><?php echo $row['profife']; ?></a></td>
        </li>
        <li class="nav-item">
        <td><a href="profile_page.php"><?php echo $row['new']; ?></a></td>
        </li>
        
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-white"  id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Output
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item"  href="login_form.php">login</a></li>
            <li><a class="dropdown-item" href="index.php">Register</a></li>
            <li><a class="dropdown-item" href="logout.php">logout</a></li>
</ul>
       </li>
      </ul>
    </div>
  </div>
</nav>
<?php
}}
?>
  <main>
  <?php
 @include 'config.php';
 $select = "SELECT * FROM homepage_tbl ORDER BY id DESC ";
 $selected = $con->query($select);
 

?>
  <?php
while( $fetch = mysqli_fetch_assoc($selected)){
  ?>

<div class="row d-flex justify-content-center">
<div class=" col-lg-8 col-md-12 col-12 ps-lg-5 mt-md-5 d-flex justify-content-center">
				<div class="card text-black text-uppercase text-center bg-white pb-2 d-flex justify-content-center" style="box-shadow: 15px 15px 40px rgba(0, 0, 0, 0.5) ; margin-bottom: 30px;" >

					<div class="card-body">
          <div>
            <?php
          if (isset($_POST["submit"])) {
 $firstName = $_POST["firstName"];
 if ($_FILES['image']["error"] === 4) {
 echo "<script> alert('Image Does Not Exist'); </script>";
 } else {
 $fileName = $_FILES["image"]["name"];
 $fileSize = $_FILES["image"]["size"];
 $tmpName = $_FILES["image"]["tmp_name"];
 $validImageExtension = ['jpg', 'jpeg', 'png'];
 $imageExtension = explode('.', $fileName);
 $imageExtension = strtolower(end($imageExtension));
 if (!in_array($imageExtension, $validImageExtension)) {
 echo "<script> alert('Invalid Image Extension'); </script>";
 } else if ($fileSize > 1000000) {
 echo "<script> alert('Image Size Is Too Large'); </script>";
 } else {
 $newImageName = uniqid();
 $newImageName .= '.' . $imageExtension;
 move_uploaded_file($tmpName, 'img/' . $newImageName);
 $query = "INSERT INTO homepage_tbl(firstname, profilepicture)
VALUES ('$firstName','$newImageName')";
 if(mysqli_query($con, $query)) {
 echo "<script> alert('Successfully Added'); document.location.href = 'home_page.php'; </script>";
 } else {
 echo "<script> alert('Error: " . mysqli_error($con) . "'); </script>";
 }
 }
 }
}
?>

<div>

  <tr>
  <th><?php echo $fetch['id']; ?></th>
   <th><?php echo $fetch["firstname"]; ?></th> 
   </tr>
  </div>
   
 <tr>
 <td><img style= "border-radius:5px; margin-bottom:5px;" src="img/<?php echo $fetch['profilepicture']; ?>" class="img-fluid rounded-square" width ="500px"title="<?php echo
$fetch['profilepicture']; ?>"></td>
<div>
 <td><a href="updatehomepage.php?id=<?php echo $fetch['id']; ?>"><button>UPDATE</button></a></td>
 <td><a href="deletehomepage.php?id=<?php echo $fetch['id']; ?>"><button>DELETE</button></a></td>
 </div>
 </tr>
 
 
 </div>
					</div>
				</div>
			</div>
     
      <?php
    
}
?>

</main>

<div class="card container mt-5 mb-5" style="box-shadow: 15px 15px 40px rgba(0, 0, 0, 0.5) ; " >
<?php
                    @include 'config.php';
                    $select = "SELECT * FROM homepage_tbl WHERE id='".$_GET['id']."'";
                    $selected = $con->query($select);
                    $row = mysqli_fetch_assoc($selected);
                    ?>
  <h1>ADD CONTENT</h1>
  <form action="updatehomepageprocess.php?id=<?php echo $_GET['id']; ?>" method="post" enctype="multipart/form-data">
    <div class="mb-3">
      <label for="firstName" class="form-label">CAPTION:</label>
      <input type="text" id="firstName" name="firstName" class="form-control" required value="<?php echo $row['firstname']; ?>">
    </div>
    <div class="mb-3">
      <label for="image" class="form-label">PICTURE:</label>
      <input type="file" id="image" name="image" class="form-control" accept=".jpg, .jpeg, .png" required>
    </div>
    <div class="mb-3">
    <button type="submit" name="submit" class="btn btn-primary">SUBMIT</button>
    </div>
  </form>
</div>

</body>
</html>