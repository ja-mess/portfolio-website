<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    

<script src="
https://cdn.jsdelivr.net/npm/sweetalert2@11.10.8/dist/sweetalert2.all.min.js
"></script>
<link href="
https://cdn.jsdelivr.net/npm/sweetalert2@11.10.8/dist/sweetalert2.min.css
" rel="stylesheet">



<?php
@include 'config.php';
session_start();

if(isset($_POST['submit'])){
  
  $fullname = $_POST['fullname'];
  $course = $_POST['course'];
  $year = $_POST['year'];
  $block = $_POST['block'];
  $address = $_POST['address'];
  $email = $_POST['email'];
  $contact = $_POST['contact_number'];
  $select = " SELECT * FROM attendance_tbl where email = '$email' ";

  $result = mysqli_query($con, $select);

  if(mysqli_num_rows($result) > 0){

     $row = mysqli_fetch_array($result);

    
      


        $_SESSION['fullname'] = $row['fullname'];
        $_SESSION['course'] = $row['course'];
        $_SESSION['year'] = $row['year'];
        $_SESSION['block'] = $row['block'];
        $_SESSION['address'] = $row['address'];
        $_SESSION['email'] = $row['email'];
        $_SESSION['contact_number'] = $row['contact_number'];
        $email = $_SESSION['email'] ;

        

    
       

     }
    }

    if($row['email'] == $email ){

 
        $fullname = $_POST['fullname'];
        $course = $_POST['course'];
        $year = $_POST['year'];
        $block = $_POST['block'];
        $address = $_POST['address'];
        $email = $_POST['email'];
        $contact = $_POST['contact_number'];
       

        $q = " INSERT INTO `attendance_tbl`(`fullname`, `course`,`year`,`block`,`address`,`email`,`contact_number`) VALUES ( '$fullname', '$course','$year','$block','$address','$email','$contact' )";

        $query = mysqli_query($con,$q);
        if ($query == true){
          $_SESSION['fullname'] = $row['fullname'];
          $_SESSION['course'] = $row['course'];
          $_SESSION['year'] = $row['year'];
          $_SESSION['block'] = $row['block'];
          $_SESSION['address'] = $row['address'];
          $_SESSION['email'] = $row['email'];
          $_SESSION['contact_number'] = $row['contact_number'];
          
            
            ?>
          
             <script>
            Swal.fire({
               icon: "success",
               title: "Success!",
               text: "Registration Successful.",
               confirmButtonText: 'OK'
               
            
             });
            
             
             </script>
            <?php
          }
    
        }
?>
 <script>
    alert("data updated");
    window.location = "user_record_attendance_page.php";
  </script>
</body>
</html>