<?php
include("config.php");
session_start();

if (!isset($_SESSION["user_type"]) || $_SESSION["user_type"] !== 'admin') {
    header("Location: index.php");
    exit;
}

$sql = "SELECT * FROM activity_logs ORDER BY timestamp DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activity Logs</title>
    <!-- Bootstrap CSS (for styling) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <!-- DataTables CSS (for table features like sorting, pagination) -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
</head>

<style>
    /* Sidebar styling */

   body {
        background-color: maroon;
        color: #fff;
        font-family: 'Segoe UI', sans-serif;
        min-height: 100vh;
    }
    .sidebar {
        position: fixed;
        top: 0;
        left: 0;
        height: 100%;
        width: 250px;
        background-color: #343a40;
        color: white;
        padding-top: 20px;
    }

    .sidebar a {
        color: white;
        text-decoration: none;
        padding: 10px 15px;
        display: block;
    }

    .sidebar a:hover {
        background-color: #007bff;
    }

    /* Main content area */
    .content {
        margin-left: 270px;
        padding: 20px;
    }

    .content h1 {
        margin-bottom: 30px;
    }

    .card {
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
    }

    .card-body {
        padding: 20px;
    }

    .btn-sm {
        padding: 5px 10px;
    }

    /* Table styling */
    .table-container {
        padding: 20px;
    }

    table.dataTable {
        width: 100% !important;
        border-collapse: collapse;
    }

    @media (max-width: 768px) {
        .sidebar {
            width: 200px;
        }

        .content {
            margin-left: 220px;
        }
    }
</style>

<body >
<?php include('admin_sidebar.php'); ?>          

    <div class="content">
        <h2>Activity Logs</h2>
      
        <!-- Table for Activity Logs -->
        <div class="card table-container">
            <div class="card-body">
                <table id="activityLogsTable" class="table table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>User ID</th>
                            <th>Username</th>
                            <th>Action</th>
                            <th>IP Address</th>
                            <th>Timestamp</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo $row['user_id']; ?></td>
                                <td><?php echo htmlspecialchars($row['username']); ?></td>
                                <td><?php echo htmlspecialchars($row['action']); ?></td>
                                <td><?php echo htmlspecialchars($row['ip_address']); ?></td>
                                <td><?php echo $row['timestamp']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- jQuery and DataTables JS (for pagination, search, and sorting functionality) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    
    <script>
        // Initialize DataTables
        $(document).ready(function() {
            $('#activityLogsTable').DataTable({
                "paging": true,      // Enable pagination
                "searching": true,   // Enable search
                "ordering": true,    // Enable sorting
                "info": true,        // Show table information
                "lengthMenu": [5, 10, 25, 50], // Set the number of entries per page
                "pageLength": 5      // Default number of records per page
            });
        });
    </script>
</body>
</html>
