<?php
session_start();
include("config.php");

// Logging function
function logAction($conn, $userId, $username, $action) {
    $ipAddress = $_SERVER['REMOTE_ADDR'];
    $stmt = $conn->prepare("INSERT INTO activity_logs (user_id, username, action, ip_address) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $userId, $username, $action, $ipAddress);
    $stmt->execute();
}

// Use session values or fallback defaults
$userId = $_SESSION['user_id'] ?? 0;
$username = $_SESSION['username'] ?? 'guest';

// Handle form submission for Add or Update
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = isset($_POST['id']) ? intval($_POST['id']) : null;
    $subject_id = intval($_POST['subject_id']);
    $type = $_POST['type']; // activity or project
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $table = ($type === 'project') ? 'projects' : 'activities';

    if ($id) {
        $stmt = $conn->prepare("UPDATE $table SET subject_id=?, title=?, description=? WHERE id=?");
        $stmt->bind_param("issi", $subject_id, $title, $description, $id);
        $stmt->execute();
        $success = ucfirst($type) . " updated successfully!";
        logAction($conn, $userId, $username, "Updated $type ID $id to title '$title'");
    } else {
        $stmt = $conn->prepare("INSERT INTO $table (subject_id, title, description) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $subject_id, $title, $description);
        $stmt->execute();
        $success = ucfirst($type) . " added successfully!";
        logAction($conn, $userId, $username, "Added $type titled '$title'");
    }
}

// Handle delete
if (isset($_GET['delete']) && isset($_GET['type'])) {
    $id = intval($_GET['delete']);
    $type = $_GET['type'];
    $table = ($type === 'project') ? 'projects' : 'activities';
    $existing = $conn->query("SELECT title FROM $table WHERE id = $id")->fetch_assoc();
    $conn->query("DELETE FROM $table WHERE id = $id");
    $success = ucfirst($type) . " deleted successfully!";
    logAction($conn, $userId, $username, "Deleted $type titled '{$existing['title']}'");
}

// Get subjects
$subjects = $conn->query("SELECT id, subject_name FROM subjects");

// Editing
$editData = null;
if (isset($_GET['edit']) && isset($_GET['type'])) {
    $id = intval($_GET['edit']);
    $type = $_GET['type'];
    $table = ($type === 'project') ? 'projects' : 'activities';
    $res = $conn->query("SELECT * FROM $table WHERE id = $id");
    $editData = $res->fetch_assoc();
}

// List entries
$currentType = $_GET['view'] ?? 'activity';
$table = ($currentType === 'project') ? 'projects' : 'activities';
$entries = $conn->query("SELECT e.id, s.subject_name, e.title, e.description 
                         FROM $table e 
                         JOIN subjects s ON e.subject_id = s.id");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CRUD: Activity/Project</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <style>
    body {
        background-color: maroon;
        color: #fff;
        font-family: 'Segoe UI', sans-serif;
        min-height: 100vh;
    }
    <style>
    body {
        background-color: maroon;
        color: #fff;
        font-family: 'Segoe UI', sans-serif;
        min-height: 100vh;
    }

    .card {
        background-color: #2c2c2c;
        color: white;
        padding: 15px;
        border-radius: 8px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        max-width: 400px; /* Reduced width */
        margin: 0 auto; /* Center the card horizontally */
    }

    .card-body {
        padding: 15px;
    }

    .btn-submit {
        background-color: #4CAF50;
        color: white;
        border: none;
    }

    .btn-submit:hover {
        background-color: #45a049;
    }
</style>


</head>
<body>
    <?php include('admin_sidebar.php'); ?>             

<div class="container-fluid">
    <div class="row justify-content-center">
      <h1 class=" text-center mb-4 " style="background:grey;">Manage Users</h1>


        <!-- Main content (centered) -->
        <div class="col-md-8">
            <div class="row">
                <!-- Form column -->
                <div class="col-md-6">
                    <h2 class="text-center mb-4"><?= $editData ? 'Edit' : 'Add' ?> Activity/Project</h2>

                    <?php if (isset($success)): ?>
                        <div class="alert alert-success text-center"><?= $success ?></div>
                    <?php endif; ?>

                    <div class="card text-white bg-dark mb-4 shadow">
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="id" value="<?= $editData['id'] ?? '' ?>">

                                <div class="mb-3">
                                    <label class="form-label">Subject</label>
                                    <select class="form-select" name="subject_id" required>
                                        <option value="">-- Select Subject --</option>
                                        <?php while ($row = $subjects->fetch_assoc()): ?>
                                            <option value="<?= $row['id'] ?>"
                                                <?= isset($editData['subject_id']) && $editData['subject_id'] == $row['id'] ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($row['subject_name']) ?>
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Type</label>
                                    <select class="form-select" name="type" required>
                                        <option value="">-- Select Type --</option>
                                        <option value="activity" <?= ($editData && $type === 'activity') ? 'selected' : '' ?>>Activity</option>
                                        <option value="project" <?= ($editData && $type === 'project') ? 'selected' : '' ?>>Project</option>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Title</label>
                                    <input type="text" class="form-control" name="title" value="<?= $editData['title'] ?? '' ?>" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Description</label>
                                    <textarea class="form-control" name="description" rows="4" required><?= $editData['description'] ?? '' ?></textarea>
                                </div>

                                <div class="d-flex justify-content-between">
                                    <button type="submit" class="btn btn-submit"><?= $editData ? 'Update' : 'Add' ?></button>
                                    <?php if ($editData): ?>
                                        <a href="?view=<?= $currentType ?>" class="btn btn-secondary">Cancel</a>
                                    <?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Table column (Activity List) -->
                <div class="col-md-6">
                    <h3 class="mb-3"><?= ucfirst($currentType) ?> List</h3>

                    <div class="mb-3 d-flex gap-2">
                        <a href="?view=activity" class="btn btn-info btn-sm <?= $currentType === 'activity' ? 'disabled' : '' ?>">View Activities</a>
                        <a href="?view=project" class="btn btn-info btn-sm <?= $currentType === 'project' ? 'disabled' : '' ?>">View Projects</a>
                    </div>

                    <div class="table-responsive">
                        <table id="entryTable" class="table table-striped table-bordered table-dark align-middle">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Subject</th>
                                    <th>Title</th>
                                    <th>Description</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $entries->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= $row['id'] ?></td>
                                        <td><?= htmlspecialchars($row['subject_name']) ?></td>
                                        <td><?= htmlspecialchars($row['title']) ?></td>
                                        <td><?= htmlspecialchars($row['description']) ?></td>
                                        <td>
                                            <a href="?edit=<?= $row['id'] ?>&type=<?= $currentType ?>&view=<?= $currentType ?>" class="btn btn-warning btn-sm">Edit</a>
                                            <a href="?delete=<?= $row['id'] ?>&type=<?= $currentType ?>&view=<?= $currentType ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this?')">Delete</a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- End of row -->
        </div> <!-- End of col-md-8 (Main Content) -->
    </div> <!-- End of row (Centered) -->
</div> <!-- End of container-fluid -->

<!-- JS dependencies -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap5.min.js"></script>

<script>
    $(document).ready(function () {
        $('#entryTable').DataTable({
            lengthMenu: [5, 10, 25, 50],
            pageLength: 5
        });
    });
</script>

</body>
</html>
