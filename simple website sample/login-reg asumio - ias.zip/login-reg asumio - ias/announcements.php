<!DOCTYPE html>
<html>
<head>
    <title>Announcements</title>
    <style>
        body {
            background-color: #800000;
            color: #fff;
            font-family: 'Segoe UI', sans-serif;
            min-height: 100vh;
            margin: 0;
            padding: 0;
            display: flex;
        }

        .main-content {
            display: flex;
            flex: 1;
            justify-content: center;
            padding: 40px;
            gap: 30px;
        }

        .container {
            max-width: 600px;
            flex: 1;
            padding: 20px;
            text-align: center;
        }

        h2 {
            font-size: 28px;
            font-weight: bold;
            color: #f4f4f4;
            margin-bottom: 20px;
        }

        .announcement-card {
            background-color: #2a2a2a;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            transition: transform 0.2s;
            text-align: left;
        }

        .announcement-card:hover {
            transform: translateY(-3px);
        }

        .announcement-title {
            font-size: 24px;
            font-weight: bold;
            color: #f4f4f4;
        }

        .announcement-dates {
            font-size: 14px;
            color: #f4f4f4;
            margin-bottom: 10px;
        }

        .announcement-content {
            color: #f4f4f4;
            font-size: 16px;
            margin-top: 10px;
            white-space: pre-line;
        }

        .announcement-image img {
            max-width: 100%;
            max-height: 200px;
            border-radius: 8px;
            margin-top: 15px;
        }

        .calendar-sidebar {
            flex: 0 0 250px;
            background-color: #2a2a2a;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            height: fit-content;
        }

        .calendar-sidebar h3 {
            font-size: 18px;
            margin-bottom: 10px;
            text-align: center;
            color: #f4f4f4;
        }

        .calendar-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 5px;
            font-size: 12px;
            text-align: center;
        }

        .calendar-grid div {
            background: #444;
            padding: 6px 0;
            border-radius: 4px;
            color: #fff;
        }

        .calendar-grid .header {
            font-weight: bold;
            background: none;
            color: #ffdddd;
        }

        .calendar-grid .today {
            background-color: #e91e63;
            font-weight: bold;
        }
    </style>
</head>
<body>
    

<?php include('sidebar.php'); ?>

<div class="main-content">
    <!-- Announcements -->
    <div class="container">
        <h2>Public Announcements</h2>

        <?php
        include 'config.php';

        if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('You must be logged in to view  this page.'); window.location.href='index.php';</script>";
    exit();
}

        $sql = "SELECT * FROM announcements ORDER BY start_date DESC";
        $result = $conn->query($sql);

        if (!$result) {
            echo "<p>Error: " . $conn->error . "</p>";
        } elseif ($result->num_rows == 0) {
            echo "<p>No announcements found.</p>";
        } else {
            while ($row = $result->fetch_assoc()):
        ?>
            <div class="announcement-card">
                <div class="announcement-title"><?= htmlspecialchars($row['title']) ?></div>
                <div class="announcement-dates">
                    <?php if ($row['start_date']) echo "From: " . $row['start_date']; ?>
                    <?php if ($row['end_date']) echo " | Until: " . $row['end_date']; ?>
                </div>
                <div class="announcement-content"><?= nl2br(htmlspecialchars($row['content'])) ?></div>
                <?php if (!empty($row['image'])): ?>
                    <div class="announcement-image">
                        <img src="<?= htmlspecialchars($row['image']) ?>" alt="Announcement Image">
                    </div>
                <?php endif; ?>
            </div>
        <?php
            endwhile;
        }
        ?>
    </div>

    <!-- Calendar -->
    <div class="calendar-sidebar">
        <h3>
            <?php
            $monthName = date("F");
            $year = date("Y");
            echo "$monthName $year";
            ?>
        </h3>
        <div class="calendar-grid">
            <?php
            $days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
            foreach ($days as $day) {
                echo "<div class='header'>$day</div>";
            }

            $currentDay = date("j");
            $currentMonth = date("n");
            $currentYear = date("Y");

            $firstDayOfMonth = mktime(0, 0, 0, $currentMonth, 1, $currentYear);
            $daysInMonth = date("t", $firstDayOfMonth);
            $startDay = date("w", $firstDayOfMonth);

            for ($i = 0; $i < $startDay; $i++) {
                echo "<div></div>";
            }

            for ($day = 1; $day <= $daysInMonth; $day++) {
                $class = ($day == $currentDay) ? "today" : "";
                echo "<div class='$class'>$day</div>";
            }
            ?>
        </div>
    </div>
</div>

</body>
</html>
