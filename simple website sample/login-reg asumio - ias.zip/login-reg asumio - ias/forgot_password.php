<?php
include("config.php");
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

// Function to send verification email
function sendVerificationEmail($email, $verification_link) {
    $mail = new PHPMailer(true);
    try {
        // Set mailer to use SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Set the SMTP server to Gmail
        $mail->SMTPAuth = true;
        $mail->Username = 'jamesbryancaberamos11@gmail.com'; // Replace with your email
        $mail->Password = 'rhdi jsvq kzgb woak'; // Replace with your Gmail app password
        $mail->SMTPSecure = 'tls'; // Enable encryption
        $mail->Port = 587; // Port for TLS

        // Sender and recipient
        $mail->setFrom('jamesbryancaberamos11@gmail.com', 'Access Control System');
        $mail->addAddress($email);

        // Set email format to HTML
        $mail->isHTML(true);
        $mail->Subject = 'Password Reset Verification';
        $mail->Body = "
        <html>
            <body>
                <p>Hello,</p>
                <p>To reset your password, click on the following link:</p>
                <a href='" . $verification_link . "'>Reset Password</a>
                <p>This link will expire in 1 hour.</p>
            </body>
        </html>";

        // Attempt to send the email
        $mail->send();
        return true; // Indicate success if no error occurs
    } catch (Exception $e) {
        // Return the full error message from PHPMailer
        return "Mailer Error: " . $e->getMessage();  // Detailed error
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['email'])) {
    $email = $_POST['email'];

    // Check if the email exists in the database
    $stmt = $conn->prepare("SELECT id, email FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // Generate a unique token for email verification
        $token = bin2hex(random_bytes(50)); // 50-byte token
        $expiry = date("Y-m-d H:i:s", strtotime("+1 hour")); // Token valid for 1 hour
        
        // Save the token and its expiration in the database
        $update = $conn->prepare("UPDATE users SET reset_token = ?, reset_token_expiration = ? WHERE id = ?");
        $update->bind_param("ssi", $token, $expiry, $user['id']);
        $update->execute();

        // Generate the verification link
$verification_link = "http://" . $_SERVER['HTTP_HOST'] . "/login-reg asumio - ias/verify_email.php?token=" . $token;

        // Send verification email with the token
        $sendResult = sendVerificationEmail($email, $verification_link);
        
        // Check if the email was sent successfully
        if ($sendResult === true) {
            echo "<script>
                    alert('A verification email has been sent to your email address. Please check your inbox.');
                    window.location.href = 'forgot_password.php?token=$token';
                  </script>";
        } else {
            echo "<script>alert('Failed to send verification email: " . $sendResult . "');</script>";
        }
    } else {
        echo "<script>alert('Email not found. Please check and try again.');</script>";
    }
}
?>

<!-- Reset Password Request Form -->
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Reset Password</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Reset Password</h2>
    <form method="POST">
        <div class="mb-3">
            <label>Email Address</label>
            <input type="email" class="form-control" name="email" required>
        </div>
        <button type="submit" class="btn btn-primary">Send Verification Email</button>
    </form>
</div>
</body>
</html>
