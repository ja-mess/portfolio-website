<!DOCTYPE html>
<html lang="en">
<head>
    <title>Welcome to Our Website</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

    <!-- Internal Dark Theme CSS -->
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #121212;
            color: #e0e0e0;
        }

        .hero {
            background: linear-gradient(to right, #1f1f1f, #2c3e50);
            color: #ffffff;
            padding: 100px 20px;
            text-align: center;
        }

        .hero h1 {
            font-size: 3rem;
            font-weight: bold;
        }

        .hero p {
            font-size: 1.2rem;
            margin-bottom: 30px;
        }

        .hero a.btn {
            padding: 10px 25px;
            font-size: 1.1rem;
        }

        section.container {
            background-color: #1e1e1e;
            padding: 60px 20px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.6);
            margin-top: 40px;
        }

        h2 {
            color: #00adb5;
            font-weight: 600;
            margin-bottom: 20px;
        }

        #contact {
            background-color: #2c2c2c;
        }

        .form-control, .form-control:focus {
            background-color: #333;
            color: #fff;
            border: 1px solid #444;
        }

        footer {
            background-color: #0d0d0d;
            color: #bbbbbb;
        }

        footer p {
            margin: 0;
            font-size: 0.9rem;
        }

        .btn-light {
            background-color: #f0f0f0;
            color: #000;
        }

        .btn-light:hover {
            background-color: #e2e2e2;
            color: #000;
        }

        .btn-primary {
            background-color: #00adb5;
            border: none;
        }

        .btn-primary:hover {
            background-color: #019aa1;
        }
    </style>
</head>
<body>

    <!-- Hero Section -->
    <section class="hero">
        <h1>Welcome to MyWebsite</h1>
        <p>Your one-stop solution for powerful experiences.</p>
        <a href="index.php" class="btn btn-light">Login to Get Started</a>
    </section>

    <!-- About Section -->
    <section id="about" class="container">
        <h2>About Us</h2>
        <p><strong>Welcome to MyWebsite!</strong> We provide sharp, modern, and powerful digital experiences. Whether you're exploring, learning, or building, our platform empowers you with performance and style. Our team delivers cutting-edge tools and support to help you get the most out of your digital journey. Join us today and be part of something bold.</p>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="container">
        <h2>Contact Us</h2>
        <p>Have questions or feedback? We'd love to hear from you.</p>
        <form class="row g-3 mt-3">
            <div class="col-md-6">
                <label for="name" class="form-label">Your Name</label>
                <input type="text" class="form-control" id="name" placeholder="John Doe">
            </div>
            <div class="col-md-6">
                <label for="email" class="form-label">Your Email</label>
                <input type="email" class="form-control" id="email" placeholder="john@example.com">
            </div>
            <div class="col-12">
                <label for="message" class="form-label">Message</label>
                <textarea class="form-control" id="message" rows="4" placeholder="Write your message here..."></textarea>
            </div>
            <div class="col-12 text-end">
                <button type="submit" class="btn btn-primary">Send Message</button>
            </div>
        </form>
    </section>

    <!-- Footer -->
    <footer class="text-center py-3">
        <p>&copy; 2025 MyWebsite. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
