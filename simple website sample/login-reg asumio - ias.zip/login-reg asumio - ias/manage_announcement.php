<?php
session_start();
include("config.php");

$message = "";
$editing = false;
$editData = [];

// Function to log actions
function logAction($conn, $userId, $action) {
    $ipAddress = $_SERVER['REMOTE_ADDR'];
    $sql = "INSERT INTO activity_logs (user_id, action, ip_address) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $userId, $action, $ipAddress);
    $stmt->execute();
}

// Handle Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    echo "
        <script>
            Swal.fire({
                title: 'Are you sure?',
                text: 'This will permanently delete the announcement.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '?confirmed_delete=true&id=' + $id;
                }
            });
        </script>";
}

// Confirm delete and perform action
if (isset($_GET['confirmed_delete'])) {
    $id = (int)$_GET['id'];
    $stmt = $conn->prepare("DELETE FROM announcements WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        // Log the action
        logAction($conn, $_SESSION['user_id'], 'Delete Announcement');
        
        echo "<script>
            Swal.fire('Deleted!', 'Announcement has been deleted.', 'success').then(() => {
                window.location.href = 'your_current_page.php'; // Redirect to the same page or your desired page after deletion
            });
        </script>";
    } else {
        echo "<script>
            Swal.fire('Error!', 'Failed to delete the announcement.', 'error');
        </script>";
    }
    $stmt->close();
}

// Handle Edit Load
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $conn->prepare("SELECT * FROM announcements WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows) {
        $editData = $result->fetch_assoc();
        $editing = true;
    }
    $stmt->close();
}

// Handle Create or Update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'] ?? null;
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $start_date = $_POST['start_date'] ?? null;
    $end_date = $_POST['end_date'] ?? null;
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    $image = null;

    // Upload image
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (in_array($_FILES['image']['type'], $allowedTypes)) {
            $dir = "uploads/";
            if (!file_exists($dir)) mkdir($dir, 0777, true);
            $filename = time() . "_" . preg_replace("/[^A-Za-z0-9_.]/", "_", basename($_FILES["image"]["name"]));
            $path = $dir . $filename;
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $path)) {
                $image = $path;
            }
        } else {
            $message = "❌ Invalid image type.";
        }
    }

    if (empty($message)) {
        if ($id) {
            // Update
            if ($image) {
                $stmt = $conn->prepare("UPDATE announcements SET title=?, content=?, image=?, start_date=?, end_date=?, is_active=?, updated_at=NOW() WHERE id=?");
                $stmt->bind_param("sssssii", $title, $content, $image, $start_date, $end_date, $is_active, $id);
            } else {
                $stmt = $conn->prepare("UPDATE announcements SET title=?, content=?, start_date=?, end_date=?, is_active=?, updated_at=NOW() WHERE id=?");
                $stmt->bind_param("ssssii", $title, $content, $start_date, $end_date, $is_active, $id);
            }
            if ($stmt->execute()) {
                // Log the action
                logAction($conn, $_SESSION['user_id'], 'Update Announcement');
                
                echo "<script>
                    Swal.fire({
                        title: 'Updated!',
                        text: 'Announcement updated successfully.',
                        icon: 'success',
                        confirmButtonColor: '#3085d6'
                    }).then(() => {
                        window.location.href = 'your_current_page.php'; // Redirect to the same page or your desired page after update
                    });
                </script>";
            } else {
                echo "<script>
                    Swal.fire({
                        title: 'Error!',
                        text: 'Failed to update announcement.',
                        icon: 'error',
                        confirmButtonColor: '#d33'
                    });
                </script>";
            }
            $stmt->close();
        } else {
            // Insert
            $stmt = $conn->prepare("INSERT INTO announcements (title, content, image, start_date, end_date, is_active, created_at, updated_at)
                                    VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())");
            $stmt->bind_param("sssssi", $title, $content, $image, $start_date, $end_date, $is_active);
            if ($stmt->execute()) {
                // Log the action
                logAction($conn, $_SESSION['user_id'], 'Create Announcement');
                
                echo "<script>
                    Swal.fire({
                        title: 'Created!',
                        text: 'Announcement created successfully.',
                        icon: 'success',
                        confirmButtonColor: '#3085d6'
                    }).then(() => {
                        window.location.href = 'your_current_page.php'; // Redirect to the same page or your desired page after insert
                    });
                </script>";
            } else {
                echo "<script>
                    Swal.fire({
                        title: 'Error!',
                        text: 'Failed to create announcement.',
                        icon: 'error',
                        confirmButtonColor: '#d33'
                    });
                </script>";
            }
            $stmt->close();
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Announcements</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>

    <style>
        body {
            background: maroon;
            color: #fff;
            font-family: 'Segoe UI', sans-serif;
            min-height: 100vh;
            padding: 20px;
        }

        .container-fluid {
            margin-left: 270px;
            padding: 0;
        }

        .card {
            background: #fff;
            color: #333;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        h2, h3 {
            color: maroon;
        }

        .message {
            background: #e0ffe0;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #b2d8b2;
            color: #2d662d;
            border-radius: 5px;
        }

        form label {
            font-weight: bold;
        }

        input[type="text"], input[type="date"], textarea {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="file"] {
            margin-bottom: 15px;
        }

        button {
            background-color: #800000;
            color: white;
            border: none;
            padding: 10px 16px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #a30000;
        }

        table.dataTable {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table.dataTable th, table.dataTable td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
            color: black;
        }

        table.dataTable thead {
            background-color: #f2f2f2;
        }

        table.dataTable tbody tr:hover {
            background-color: #f0f0f0;
        }

        img {
            max-height: 60px;
            border-radius: 5px;
        }

        .action-buttons a {
            margin: 0 5px;
            color: #007bff;
            text-decoration: none;
        }

        .action-buttons a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<?php include('admin_sidebar.php'); ?>

<div class="container-fluid">
    <div class="card">
        <h2><?= $editing ? 'Edit' : 'Create' ?> Announcement</h2>

        <?php if (!empty($message)): ?>
            <div class="message"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <?php if ($editing): ?>
                <input type="hidden" name="id" value="<?= $editData['id'] ?>">
            <?php endif; ?>

            <label>Title:</label>
            <input type="text" name="title" value="<?= $editing ? htmlspecialchars($editData['title']) : '' ?>" required>

            <label>Content:</label>
            <textarea name="content" rows="4" required><?= $editing ? htmlspecialchars($editData['content']) : '' ?></textarea>

            <label>Image:</label><br>
            <?php if ($editing && $editData['image']): ?>
                <img src="<?= $editData['image'] ?>" width="100"><br><br>
            <?php endif; ?>
            <input type="file" name="image">

            <label>Start Date:</label>
            <input type="date" name="start_date" value="<?= $editing ? $editData['start_date'] : '' ?>">

            <label>End Date:</label>
            <input type="date" name="end_date" value="<?= $editing ? $editData['end_date'] : '' ?>">

            <label>Is Active:</label>
            <input type="checkbox" name="is_active" <?= $editing && $editData['is_active'] ? 'checked' : (!$editing ? 'checked' : '') ?>><br><br>

            <button type="submit"><?= $editing ? 'Update' : 'Submit' ?></button>
        </form>
    </div>

    <div class="card">
        <h3>All Announcements</h3>
        <table id="userListTable" class="display">
            <thead>
                <tr>
                    <th>ID</th><th>Title</th><th>Active</th><th>Start</th><th>End</th><th>Image</th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $result = $conn->query("SELECT * FROM announcements ORDER BY id DESC");
            while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= htmlspecialchars($row['title']) ?></td>
                    <td><?= $row['is_active'] ? '✅' : '❌' ?></td>
                    <td><?= $row['start_date'] ?></td>
                    <td><?= $row['end_date'] ?></td>
                    <td><?php if ($row['image']): ?><img src="<?= $row['image'] ?>" width="60"><?php endif; ?></td>
                    <td class="action-buttons">
                        <a href="?edit=<?= $row['id'] ?>" class="btn btn-success btn-sm">Edit</a>
                        <a href="?delete=<?= $row['id'] ?>" onclick="return false;" id="delete-<?= $row['id'] ?>" class="btn btn-danger btn-sm">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#userListTable').DataTable();

        // SweetAlert Delete Confirmation
        $('[id^="delete-"]').on('click', function() {
            const id = $(this).attr('id').split('-')[1];
            Swal.fire({
                title: 'Are you sure?',
                text: 'This will permanently delete the announcement.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '?confirmed_delete=true&id=' + id;
                }
            });
        });
    });
</script>
</body>
</html>
