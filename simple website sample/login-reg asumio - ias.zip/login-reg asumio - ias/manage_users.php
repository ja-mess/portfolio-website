<?php
session_start();
include("config.php");

// Check if user is logged in and is admin
if (!isset($_SESSION['user']) || $_SESSION['user_type'] !== 'admin') {
    echo "<script>alert('Access Denied! Admins only.'); window.location.href='index.php';</script>";
    exit();
}

// Initialize variables
$username = "";
$email = "";
$password = "";
$userId = "";
$userType = "user"; // Default to "user" type
$isEdit = false;

// Function to log actions
function logAction($conn, $userId, $action) {
    $ipAddress = $_SERVER['REMOTE_ADDR'];
    $sql = "INSERT INTO activity_logs (user_id, action, ip_address) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $userId, $action, $ipAddress);
    $stmt->execute();
}

// Handle add or edit user form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $userType = $_POST['user_type']; // Get the user type from the form
    
    if (isset($_POST['userId']) && !empty($_POST['userId'])) {
        // Edit user
        $userId = $_POST['userId'];
        $sql = "UPDATE users SET username=?, email=?, user_type=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $username, $email, $userType, $userId);
        $action = 'Edit User'; // Action description
    } else {
        // Add user
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (username, email, password, user_type) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $username, $email, $password, $userType);
        $action = 'Add User'; // Action description
    }
    
    if ($stmt->execute()) {
        logAction($conn, $_SESSION['user_id'], $action); // Log the action
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'success',
                    title: 'Success!',
                    text: 'User " . ($isEdit ? 'updated' : 'added') . " successfully.',
                    confirmButtonColor: '#3085d6',
                    confirmButtonText: 'OK'
                }).then(() => {
                    window.location.href = 'manage_users.php';
                });
            });
        </script>";
    } else {
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'Something went wrong.',
                    confirmButtonColor: '#d33',
                    confirmButtonText: 'OK'
                }).then(() => {
                    window.location.href = 'manage_users.php';
                });
            });
        </script>";
    }
}

// Handle edit action
if (isset($_GET['edit'])) {
    $userId = $_GET['edit'];
    $sql = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $username = $result['username'];
    $email = $result['email'];
    $userType = $result['user_type']; // Get user type
    $isEdit = true;
}

// Handle delete action
if (isset($_GET['delete'])) {
    $userId = $_GET['delete'];
    $deleteSql = "DELETE FROM users WHERE id = ?";
    $stmt = $conn->prepare($deleteSql);
    $stmt->bind_param("i", $userId);
    if ($stmt->execute()) {
        logAction($conn, $_SESSION['user_id'], 'Delete User'); // Log the action
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'success',
                    title: 'Deleted!',
                    text: 'User has been deleted.',
                    confirmButtonColor: '#3085d6',
                    confirmButtonText: 'OK'
                }).then(() => {
                    window.location.href = 'manage_users.php';
                });
            });
        </script>";
    } else {
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'Failed to delete user.',
                    confirmButtonColor: '#d33',
                    confirmButtonText: 'OK'
                }).then(() => {
                    window.location.href = 'manage_users.php';
                });
            });
        </script>";
    }
}

// Fetch only users with user_type = 'user'
$sql = "SELECT * FROM users WHERE user_type = 'user'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Users</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
    <!-- SweetAlert2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.3/dist/sweetalert2.min.css" rel="stylesheet">
</head>
<style>
body {
    background-color: #800000; /* Maroon background */
    color: #fff;
    font-family: 'Segoe UI', sans-serif;
    min-height: 100vh;
}

.card-header {
    background-color: #6c757d; /* Grey background for card header */
    color: white;
    font-weight: bold;
}

.card-body {
    background-color: #f0f0f0; /* Light grey background */
}

.card {
    border-radius: 10px; /* Optional: adds rounded corners to the card */
    overflow: hidden;
}

.card-header, .card-body {
    padding: 20px;
}

form .form-control {
    max-width: 100%; /* Ensures the form controls fit the card width */
}

/* Edit and Delete Buttons */
.btn-warning {
    background-color: #800000; /* Maroon color for Edit button */
    border-color: #800000; /* Maroon border */
    color: white; /* White text for Edit button */
}

.btn-danger {
    background-color: #800000; /* Maroon color for Delete button */
    border-color: #800000; /* Maroon border */
}

.btn-warning:hover, .btn-danger:hover {
    background-color: #660000; /* Darker maroon color on hover */
    border-color: #660000; /* Darker maroon border on hover */
}

/* Add User Button */
.btn-success {
    background-color: #800000; /* Maroon color for Add User button */
    border-color: #800000; /* Maroon border */
}

.btn-success:hover {
    background-color: #660000; /* Darker maroon color on hover */
    border-color: #660000; /* Darker maroon border on hover */
}
</style>


<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <?php include('admin_sidebar.php'); ?>          

        <!-- Main Content -->
        <div class="container-fluid" style="margin-left: 270px; padding: 20px;">
            <h1 class="text-center mb-4">Manage Users</h1>

            <!-- Add/Edit User Form Card -->
            <div class="row mb-4 justify-content-center">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h2><?php echo $isEdit ? 'Edit User' : 'Add User'; ?></h2>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="userId" value="<?php echo htmlspecialchars($userId); ?>">
                                <div class="mb-3">
                                    <label class="form-label">Username</label>
                                    <input type="text" name="username" class="form-control" value="<?php echo htmlspecialchars($username); ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>" required>
                                </div>
                                <!-- User Type Dropdown -->
                                <div class="mb-3">
                                    <label class="form-label">User Type</label>
                                    <select name="user_type" class="form-control" required>
                                        <option value="user" <?php echo $userType === 'user' ? 'selected' : ''; ?>>User</option>
                                        <option value="admin" <?php echo $userType === 'admin' ? 'selected' : ''; ?>>Admin</option>
                                    </select>
                                </div>
                                <?php if (!$isEdit): ?>
                                    <div class="mb-3">
                                        <label class="form-label">Password</label>
                                        <input type="password" name="password" class="form-control" required>
                                    </div>
                                <?php endif; ?>
                                <button type="submit" class="btn btn-success w-100"><?php echo $isEdit ? 'Update User' : 'Add User'; ?></button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- User List Card -->
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h2>User List</h2>
                        </div>
                        <div class="card-body">
                            <table id="userListTable" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Username</th>
                                        <th>Email</th>
                                        <th>User Type</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($row = $result->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo $row['id']; ?></td>
                                            <td><?php echo $row['username']; ?></td>
                                            <td><?php echo $row['email']; ?></td>
                                            <td><?php echo $row['user_type']; ?></td>
                                            <td>
                                                <a href="manage_users.php?edit=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                                <a href="#" onclick="confirmDelete(<?php echo $row['id']; ?>)" class="btn btn-danger btn-sm">Delete</a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery and DataTables JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>

    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        // Initialize DataTables
        $(document).ready(function() {
            $('#userListTable').DataTable({
                "paging": true,      // Enable pagination
                "searching": true,   // Enable search
                "ordering": true,    // Enable sorting
                "info": true,        // Show table information
                "lengthMenu": [5, 10, 25, 50], // Set the number of entries per page
                "pageLength": 5      // Default number of records per page
            });
        });

        function confirmDelete(id) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'manage_users.php?delete=' + id;
                }
            });
        }
    </script>
</body>
</html>