<?php
session_start();
date_default_timezone_set('UTC');

// Limit settings
$rateLimit = 10; // Maximum requests
$timeFrame = 60; // Time in seconds (1 minute)

// IP-based key
$clientIP = $_SERVER['REMOTE_ADDR'];

// Initialize session for IP if not already set
if (!isset($_SESSION['rate_limit'][$clientIP])) {
    $_SESSION['rate_limit'][$clientIP] = [
        'requests' => 0,
        'start_time' => time()
    ];
}

// Fetch the current data
$currentData = &$_SESSION['rate_limit'][$clientIP];

// Reset the counter if time has passed
if (time() - $currentData['start_time'] > $timeFrame) {
    $currentData['requests'] = 0;
    $currentData['start_time'] = time();
}

// Log the attempt
$currentData['requests']++;

// Log to a file
file_put_contents('rate_limit_logs.txt', date('Y-m-d H:i:s') . " - IP: $clientIP - Request Count: " . $currentData['requests'] . "\n", FILE_APPEND);

// Check if rate limit is exceeded
if ($currentData['requests'] > $rateLimit) {
    header('HTTP/1.1 429 Too Many Requests');
    echo "<h3>You have exceeded the rate limit. Please try again later.</h3>";
    exit();
}
?>
