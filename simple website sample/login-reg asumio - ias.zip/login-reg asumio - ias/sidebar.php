<style>


.sidebar {
    height: 100vh;
    background-color: #111;
    padding: 20px;
    position: fixed;
    width: 250px;
    top: 0;
    left: 0;
}

.sidebar h2 {
    color: #00adb5;
    margin-bottom: 30px;
}

.sidebar a,
.sidebar form button {
    display: block;
    color: #ddd;
    padding: 10px 15px;
    margin-bottom: 10px;
    background-color: #1f1f1f;
    border: none;
    text-align: left;
    text-decoration: none;
    border-radius: 5px;
    transition: background 0.2s ease;
}

.sidebar a:hover,
.sidebar form button:hover {
    background-color: #00adb5;
    color: #fff;
}

#logout-btn {
    display: block;
    color: #ddd;
    padding: 10px 15px;
    margin-bottom: 10px;
    background-color: #1f1f1f;
    border: none;
    text-align: left;
    text-decoration: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background 0.2s ease;
}

#logout-btn:hover {
    background-color: #00adb5;
    color: #fff;
}
</style>

<div class="sidebar">
    <h2>Student Portal</h2>
  
    <a href="user_page.php">My Subjects</a>
    <a href="announcements.php">Announcements</a>
    <a href="profile.php">Profile</a>
    <form id="logout-form" action="logout.php" method="post" style="display: none;">
        <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($_SESSION['user_id']); ?>">
    </form>
    <button type="button" id="logout-btn">Logout</button>
</div>

<!-- SweetAlert2 CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
document.getElementById('logout-btn').addEventListener('click', function (e) {
    e.preventDefault();

    Swal.fire({
        title: 'Are you sure?',
        text: "You are about to log out.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, logout'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('logout-form').submit();
        }
    });
});
</script>
