<?php
session_start();
include("config.php");

if (!isset($_GET['subject_id'])) {
    die("Subject ID is required.");
}

$subject_id = intval($_GET['subject_id']);

// Handle activity/project image uploads
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type']; // activity or project
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $table = ($type === 'project') ? 'projects' : 'activities';

    $imageName = null;

    if (!empty($_FILES['image']['name'])) {
        $targetDir = "uploads/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);
        $imageName = uniqid() . "_" . basename($_FILES["image"]["name"]);
        $targetFile = $targetDir . $imageName;
        move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile);
    }

    $stmt = $conn->prepare("INSERT INTO $table (subject_id, title, description, image) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $subject_id, $title, $description, $imageName);
    $stmt->execute();
}

// Get subject
$subject = $conn->query("SELECT * FROM subjects WHERE id = $subject_id")->fetch_assoc();

// Fetch entries
$activities = $conn->query("SELECT * FROM activities WHERE subject_id = $subject_id");
$projects = $conn->query("SELECT * FROM projects WHERE subject_id = $subject_id");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Subject Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
        background-color: #800000; /* Maroon background */
        color: #fff;
        font-family: 'Segoe UI', sans-serif;
        min-height: 100vh;
    }
    .section-title { 
        color: white;  /* White color for section titles */
    }
    .card {
        background-color: #2a2a2a;
        margin-bottom: 20px;
        border: none;
        padding: 10px;  /* Reduced padding */
        width: 80%;  /* Set a fixed width for the card */
        margin-left: auto;  /* Center the card horizontally */
        margin-right: auto;
    }
    .card-title { 
        color: white;  /* White color for card titles */
    }
    .card-text { 
        color: #ccc; 
    }
    img.preview {
        max-width: 150px;  /* Reduced max width for images */
        margin-top: 10px;
        border-radius: 10px;
    }
    .container {
        max-width: 800px;
    }
    .bg-dark-custom {
        background-color: #343a40;
    }
    .white-text {
        color: white;
    }
</style>

</head>
<body>

<div class="container mt-5">
    <!-- Subject details without card -->
    <h2 class="section-title"><?= htmlspecialchars($subject['subject_name']) ?></h2>
    <p class="white-text"><?= htmlspecialchars($subject['description']) ?></p>
    <p class="white-text"><strong>Instructor:</strong> <?= htmlspecialchars($subject['instructor']) ?></p>

    <hr>

    <?php if ($activities->num_rows > 0): ?>
    <div class="card bg-dark-custom">
        <div class="card-body">
            <h4 class="section-title">Add Activity or Project</h4>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="subject_id" value="<?= $subject_id ?>">
                <div class="mb-3">
                    <label class="form-label">Type</label>
                    <select name="type" class="form-select" required>
                        <option value="">-- Select Type --</option>
                        <option value="activity">Activity</option>
                        <option value="project">Project</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Title</label>
                    <input type="text" name="title" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Description</label>
                    <textarea name="description" rows="4" class="form-control" required></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Image (optional)</label>
                    <input type="file" name="image" class="form-control">
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <!-- Activities Section -->
    <div class="card mt-4">
        <div class="card-body">
            <h4 class="section-title">Activities</h4>
            <?php if ($activities->num_rows > 0): ?>
                <?php while ($activity = $activities->fetch_assoc()): ?>
                    <div class="card mb-3">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($activity['title']) ?></h5>
                            <p class="card-text"><?= nl2br(htmlspecialchars($activity['description'])) ?></p>
                            <?php if ($activity['image']): ?>
                                <img src="uploads/<?= htmlspecialchars($activity['image']) ?>" class="preview" alt="Activity Image">
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <!-- No activities found message inside a card with white text -->
                <div class="card">
                    <div class="card-body">
                        <p class="white-text">No activities found.</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Projects Section -->
    <div class="card mt-4">
        <div class="card-body">
            <h4 class="section-title">Projects</h4>
            <?php if ($projects->num_rows > 0): ?>
                <?php while ($project = $projects->fetch_assoc()): ?>
                    <div class="card mb-3">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($project['title']) ?></h5>
                            <p class="card-text"><?= nl2br(htmlspecialchars($project['description'])) ?></p>
                            <?php if ($project['image']): ?>
                                <img src="uploads/<?= htmlspecialchars($project['image']) ?>" class="preview" alt="Project Image">
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <!-- No projects found message inside a card with white text -->
                <div class="card">
                    <div class="card-body">
                        <p class="white-text">No projects found.</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

</body>
</html>
