<?php
session_start();
include("config.php");
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('You must be logged in to view  this page.'); window.location.href='index.php';</script>";
    exit();
}

// Rate Limiting Logic
$user_id = $_SESSION['user_id'];
$endpoint = "search_subjects";
$limit = 10;
$time_frame = 60;

// Check the count of requests made in the last minute
$sql = "SELECT COUNT(*) as request_count FROM rate_logs 
        WHERE user_id = ? AND endpoint = ? AND request_time > NOW() - INTERVAL ? SECOND";
$stmt = $conn->prepare($sql);
$stmt->bind_param("isi", $user_id, $endpoint, $time_frame);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

// If limit is reached, show an alert and prevent search
if ($row['request_count'] >= $limit) {
    echo '<div class="alert alert-danger text-center" role="alert">
            Rate limit exceeded. Please wait and try again.
          </div>';
    exit;
}

// Log the request
$sql = "INSERT INTO rate_logs (user_id, endpoint) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $user_id, $endpoint);
$stmt->execute();

// Handle search query
$search = isset($_GET['search']) ? $_GET['search'] : '';
$sql = "SELECT * FROM subjects WHERE subject_name LIKE ?";
$stmt = $conn->prepare($sql);
$likeSearch = "%" . $search . "%";
$stmt->bind_param("s", $likeSearch);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Student Portal</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: maroon;
            color: #f0f0f0;
            font-family: 'Segoe UI', sans-serif;
        }

        .sidebar {
            height: 100vh;
            background-color: #111;
            padding: 20px;
            position: fixed;
            width: 250px;
        }

        .sidebar h2 {
            color: black;
            margin-bottom: 30px;
        }

        .sidebar a, .sidebar form button {
            display: block;
            color: #ddd;
            padding: 10px 15px;
            margin-bottom: 10px;
            background-color: #1f1f1f;
            border: none;
            text-align: left;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.2s ease;
        }

        .sidebar a:hover, .sidebar form button:hover {
            background-color: #00adb5;
            color: #fff;
        }

        .content {
            margin-left: 270px;
            padding: 40px 20px;
        }

        .card {
            background-color: grey;
            border: none;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .card:hover {
            transform: scale(1.02);
            box-shadow: 0 4px 20px rgba(0, 173, 181, 0.4);
        }

        .card-title {
            color: #00adb5;
            font-size: 1.2rem;
            font-weight: 600;
        }

        .card-text {
            color: black;
        }

        .btn-info {
            background-color: maroon;
            border: none;
            color: white;
        }

        .btn-info:hover {
            background-color: #4f0000;
        }

        h3 {
            color: white;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<?php include('sidebar.php'); ?>

<!-- Content -->
<div class="content">
    <h2>Welcome, <?php echo htmlspecialchars($_SESSION["user"]); ?>!</h2>
    <p>Student ID: <?php echo htmlspecialchars($_SESSION['user_id']); ?></p>

    <h3 class="mt-5">Enrolled Subjects</h3>
    <form method="get" class="mb-4 d-flex">
    <input type="text" name="search" class="form-control me-2" placeholder="Search subjects..." value="<?php echo htmlspecialchars($search); ?>" style="width: 250px;">
    <button type="submit" class="btn btn-secondary">Search</button>
</form>

    <div class="row mt-4">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='col-lg-4 col-md-6 col-sm-12 mb-4'>
                        <div class='card h-100'>
                            <div class='card-body d-flex flex-column justify-content-between'>
                                <h5 class='card-title' style='color: black; font-weight: bold;'>" . htmlspecialchars($row['subject_name']) . "</h5>
                                <p class='card-text'>" . htmlspecialchars($row['description']) . "</p>
                                <p class='card-text'><strong>Instructor:</strong> " . htmlspecialchars($row['instructor']) . "</p>
                                <form action='subject_details.php' method='get'>
                                    <input type='hidden' name='subject_id' value='" . htmlspecialchars($row['id']) . "'>
                                    <div class='d-grid'>
                                        <button type='submit' class='btn btn-info'>View Details</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>";
            }
        } else {
            echo "<p class='text-center'>No subjects found.</p>";
        }
        ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
