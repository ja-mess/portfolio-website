<!DOCTYPE html>
<html lang="en">
<head>
    <title>Welcome to Our Website</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
  
    <!-- Hero Section -->
    <section class="bg-primary text-white text-center py-5">
        <h1>Welcome to MyWebsite</h1>
        <p>Your one-stop solution for amazing experiences.</p>
        <a href="index.php" class="btn btn-light">Login to Get Started</a>
    </section>

    <!-- About Section -->
    <section id="about" class="container py-5">
        <h2>About Us</h2>
        <p>Here's a simple and engaging about paragraph for your website:  

> **Welcome to MyWebsite!**  
> At MyWebsite, we are committed to providing exceptional experiences and top-quality services. Whether you're here to explore, learn, or connect, our platform offers a seamless and enjoyable journey. Our dedicated team works tirelessly to ensure your satisfaction, offering innovative solutions and personalized experiences. Join us today and discover what makes MyWebsite a preferred choice for so many.  

Let me know if you'd like any tweaks or additional information!</p>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="container py-5">
        <h2>Contact Us</h2>
        <p>If you have any questions, feel free to reach out!</p>
    </section>

    <!-- Footer -->
    <footer class="text-center py-3 bg-light">
        <p>&copy; 2025 MyWebsite. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
