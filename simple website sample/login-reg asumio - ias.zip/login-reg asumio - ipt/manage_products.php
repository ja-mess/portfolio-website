<?php
session_start();
include("config.php");

// Check if user is logged in and is admin
if (!isset($_SESSION['user']) || $_SESSION['user_type'] !== 'admin') {
    echo "<script>alert('Access Denied! Admins only.'); window.location.href='index.php';</script>";
    exit();
}

// Initialize variables
$name = "";
$price = "";
$productId = null;
$image = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $productId = isset($_POST['product_id']) ? $_POST['product_id'] : null;

    // Handle image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $imageTmpPath = $_FILES['image']['tmp_name'];
        $imageName = $_FILES['image']['name'];
        $imageExtension = pathinfo($imageName, PATHINFO_EXTENSION);

        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        if (in_array(strtolower($imageExtension), $allowedExtensions)) {
            $uploadDir = 'uploads/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            $newImageName = uniqid('product_', true) . '.' . $imageExtension;
            $imageDestPath = $uploadDir . $newImageName;

            if (move_uploaded_file($imageTmpPath, $imageDestPath)) {
                $image = $newImageName;
            } else {
                echo "<script>alert('Error uploading image.');</script>";
            }
        } else {
            echo "<script>alert('Invalid image format. Allowed formats: jpg, jpeg, png, gif.');</script>";
        }
    }

    if ($productId) {
        // Update product
        if ($image) {
            $sql = "UPDATE products SET name = ?, price = ?, image = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sdsi", $name, $price, $image, $productId);
        } else {
            $sql = "UPDATE products SET name = ?, price = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sdi", $name, $price, $productId);
        }
        $stmt->execute();
        echo "<script>alert('Product updated successfully!'); window.location.href='manage_products.php';</script>";
    } else {
        // Add new product
        $sql = "INSERT INTO products (name, price, image) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sds", $name, $price, $image);
        $stmt->execute();
        echo "<script>alert('Product added successfully!'); window.location.href='manage_products.php';</script>";
    }
}

// Handle delete action
if (isset($_GET['delete'])) {
    $productId = $_GET['delete'];
    $fetchImageSql = "SELECT image FROM products WHERE id = ?";
    $stmt = $conn->prepare($fetchImageSql);
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();

    if ($product && $product['image']) {
        $imagePath = 'uploads/' . $product['image'];
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }
    }

    $deleteSql = "DELETE FROM products WHERE id = ?";
    $stmt = $conn->prepare($deleteSql);
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    echo "<script>alert('Product deleted successfully!'); window.location.href='manage_products.php';</script>";
}

// Fetch product for editing
if (isset($_GET['edit'])) {
    $productId = $_GET['edit'];
    $editSql = "SELECT * FROM products WHERE id = ?";
    $stmt = $conn->prepare($editSql);
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();
    $name = $product['name'];
    $price = $product['price'];
    $image = $product['image'];
}

$sql = "SELECT * FROM products";
$result = $conn->query($sql);
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin - Manage Products</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="d-flex justify-content-center align-items-center vh-100 bg-light">
    <div class="container">
        <h1 class="text-center mb-4">Manage Products</h1>
        <a href="admin_dashboard.php" class="btn btn-secondary mb-4">Back to Dashboard</a>

        <div class="row g-4">
            <!-- Add/Edit Product Form -->
            <div class="col-md-5">
                <div class="card p-4 shadow">
                    <h2 class="mb-3"><?php echo $productId ? 'Edit Product' : 'Add Product'; ?></h2>
                    <form method="post" enctype="multipart/form-data">
                        <input type="hidden" name="product_id" value="<?php echo $productId; ?>">
                        <div class="mb-3">
                            <label class="form-label">Product Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($name); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Price</label>
                            <input type="number" step="0.01" name="price" class="form-control" value="<?php echo htmlspecialchars($price); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Product Image</label>
                            <input type="file" name="image" class="form-control" accept="image/*">
                        </div>
                        <button type="submit" class="btn btn-primary w-100">
                            <?php echo $productId ? 'Update Product' : 'Add Product'; ?>
                        </button>
                    </form>
                </div>
            </div>

            <!-- Product Grid View -->
            <div class="col-md-7">
                <h2 class="mb-3">Product List</h2>
                <div class="row row-cols-1 row-cols-md-2 g-4">
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <div class="col">
                            <div class="card h-100 shadow-sm">
                                <?php if ($row['image']): ?>
                                    <img src="uploads/<?php echo $row['image']; ?>" class="card-img-top" alt="<?php echo htmlspecialchars($row['name']); ?>" style="height: 200px; object-fit: cover;">
                                <?php endif; ?>
                                <div class="card-body">
                                    <h5 class="card-title">ID: <?php echo $row['id']; ?></h5>
                                    <h6 class="card-subtitle mb-2 text-muted">Name: <?php echo htmlspecialchars($row['name']); ?></h6>
                                    <p class="card-text">Price: $<?php echo number_format($row['price'], 2); ?></p>
                                    <div class="d-flex gap-2">
                                        <a href="manage_products.php?edit=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                        <a href="manage_products.php?delete=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');">Delete</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>