<?php
session_start();
include("config.php");
if (!isset($_SESSION["user"]) || !isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

// Fetch products from the database
$sql = "SELECT * FROM products";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>User Page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="user_page.php">MyShop</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <div class="ms-auto d-flex gap-2">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="profile.php" class="btn btn-outline-light">Profile</a>
                    <form action="logout.php" method="post" style="display:inline;">
                        <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($_SESSION['user_id']); ?>">
                        <button type="submit" class="btn btn-danger">Logout</button>
                    </form>
                <?php else: ?>
                    <a href="login.php" class="btn btn-primary">Login</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>


    <!-- Content -->
    <div class="container mt-5">
        <h2 class="text-center text-white">Welcome, <?php echo htmlspecialchars($_SESSION["user"]); ?> (User ID: <?php echo htmlspecialchars($_SESSION['user_id']); ?>)!</h2>

        <h3 class="mt-5" id="products">Shop Now</h3>
        <div class="row mt-3">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<div class='col-lg-3 col-md-4 col-sm-6 mb-4'>
                        <div class='card shadow-sm h-100'>";
                    if (!empty($row['image'])) {
                        echo "<img src='uploads/" . htmlspecialchars($row['image']) . "' class='card-img-top' alt='school Image' style='height: 200px; object-fit: cover;'>";
                    }
                    echo "<div class='card-body'>
                            <h5 class='card-title'>" . htmlspecialchars($row['name']) . "</h5>
                            <p class='card-text'>" . htmlspecialchars($row['description']) . "</p>
                            <p class='card-text'><strong>$" . number_format($row['price'], 2) . "</strong></p>";

                 
               

                            echo "<form action='checkout.php' method='post'>
                            <input type='hidden' name='product_id' value='" . htmlspecialchars($row['id']) . "'>
                            <div class='d-flex justify-content-center'>
                                <button type='submit' class='btn btn-success' name='buy_now'>Buy Now</button>
                            </div>
                        </form>
                        
                    </div>
                </div>
                </div>";
                }
            } else {
                echo "<p class='text-center'>No products available</p>";
            }
            ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
