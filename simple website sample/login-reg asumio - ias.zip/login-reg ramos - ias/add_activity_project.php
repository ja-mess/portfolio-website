<?php
session_start();
include("config.php");

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $subject_id = intval($_POST['subject_id']);
    $type = $_POST['type']; // activity or project
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);

    if ($type === 'activity') {
        $stmt = $conn->prepare("INSERT INTO activities (subject_id, title, description) VALUES (?, ?, ?)");
    } else {
        $stmt = $conn->prepare("INSERT INTO projects (subject_id, title, description) VALUES (?, ?, ?)");
    }

    $stmt->bind_param("iss", $subject_id, $title, $description);

    if ($stmt->execute()) {
        $success = "$type successfully added!";
    } else {
        $error = "Error adding $type.";
    }
}

// Fetch subjects for dropdown
$subjects = $conn->query("SELECT id, subject_name FROM subjects");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Activity/Project</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #1a1a1a;
            color: #f0f0f0;
            font-family: 'Segoe UI', sans-serif;
        }
        .content {
            margin-left: 270px;
            padding: 40px 20px;
        }
        h2 {
            color: #00adb5;
        }
        .form-control, .form-select {
            background-color: #2a2a2a;
            border: 1px solid #444;
            color: white;
        }
        .form-control::placeholder {
            color: #bbb;
        }
        .btn-submit {
            background-color: #00adb5;
            border: none;
        }
        .btn-submit:hover {
            background-color: #019aa1;
        }
        .alert {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<?php include('admin_sidebar.php'); ?>

<div class="content">
    <h2>Add Activity or Project</h2>

    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php elseif (isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="mb-3">
            <label for="subject_id" class="form-label">Subject</label>
            <select class="form-select" name="subject_id" required>
                <option value="">-- Select Subject --</option>
                <?php while ($row = $subjects->fetch_assoc()): ?>
                    <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['subject_name']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="type" class="form-label">Type</label>
            <select class="form-select" name="type" required>
                <option value="">-- Select Type --</option>
                <option value="activity">Activity</option>
                <option value="project">Project</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Title</label>
            <input type="text" class="form-control" name="title" placeholder="Enter title" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea class="form-control" name="description" rows="4" placeholder="Enter description" required></textarea>
        </div>

        <button type="submit" class="btn btn-submit">Add</button>
    </form>
</div>

</body>
</html>
