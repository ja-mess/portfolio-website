<!DOCTYPE html>
<html>
<head>
    <title>Announcements</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        background-color: #D3D3D3;
            margin: 0;
            padding: 50px;
        }

        .container {
            max-width: 1000px;
            margin: 40px auto;
            padding: 20px;
        }

        .announcement-card {
            background-color: #2a2a2a;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            transition: transform 0.2s;
        }

        .announcement-card:hover {
            transform: translateY(-3px);
        }

        .announcement-title {
            font-size: 24px;
            font-weight: bold;
            color: #f4f4f4;
        }

        .announcement-dates {
            font-size: 14px;
            color:#f4f4f4;
            margin-bottom: 10px;
        }

        .announcement-content {
            color:#f4f4f4;
            font-size: 16px;
            margin-top: 10px;
            white-space: pre-line;
        }

        .announcement-image img {
            max-width: 100%;
            max-height: 200px;
            border-radius: 8px;
            margin-top: 15px;
        }
    </style>
</head>
<body>

<?php include('sidebar.php'); ?>

<div class="container" style="margin-left: 270px;">
    <h2>Public Announcements</h2>

    <?php
    include 'config.php';


    $sql = "SELECT * FROM announcements 
          ";

    $result = $conn->query($sql);

    if (!$result) {
        echo "<p>Error: " . $conn->error . "</p>";
    } elseif ($result->num_rows == 0) {
        echo "<p>No announcements found.</p>";
    } else {
        while ($row = $result->fetch_assoc()):
    ?>
        <div class="announcement-card">
            <div class="announcement-title"><?= htmlspecialchars($row['title']) ?></div>
            <div class="announcement-dates">
                <?php if ($row['start_date']) echo "From: " . $row['start_date']; ?>
                <?php if ($row['end_date']) echo " | Until: " . $row['end_date']; ?>
            </div>
            <div class="announcement-content"><?= nl2br(htmlspecialchars($row['content'])) ?></div>
            <?php if (!empty($row['image'])): ?>
                <div class="announcement-image">
                    <img src="<?= htmlspecialchars($row['image']) ?>" alt="Announcement Image">
                </div>
            <?php endif; ?>
        </div>
    <?php
        endwhile;
    }
    ?>
</div>

</body>
</html>
