<?php
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    $user_type = $_POST["user_type"];
    $number = $_POST["number"];
    $address = $_POST["address"];
    $recaptchaResponse = $_POST['g-recaptcha-response'];

    // Verify reCAPTCHA
    $secretKey = '6LeYi4gqAAAAAIqKpwb_3BdvHYKsfWT8YrvHT2jE';
    $verifyResponse = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secretKey&response=$recaptchaResponse");
    $responseData = json_decode($verifyResponse);

    if (!$responseData->success) {
        echo "<script>alert('reCAPTCHA verification failed. Please try again.'); window.history.back();</script>";
        exit();
    }

    // Handle image upload
    $imageName = "";
    if (isset($_FILES["image"]) && $_FILES["image"]["error"] === 0) {
        $targetDir = "uploads/";
        $imageName = uniqid() . "_" . basename($_FILES["image"]["name"]);
        $targetFile = $targetDir . $imageName;
        move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile);
    }

    if ($user_type != 'admin' && $user_type != 'user') {
        echo "<script>alert('Invalid user type!');</script>";
        exit();
    }

    // Check if email already exists
    $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        echo "<script>alert('Email is already registered. Please use another.'); window.history.back();</script>";
        exit();
    }
    $check->close();

    // Insert new user
    $sql = "INSERT INTO users (username, email, password, user_type, number, address, image) VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssss", $username, $email, $password, $user_type, $number, $address, $imageName);

    if ($stmt->execute()) {
        echo "<script>alert('Registered successfully!'); window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('Error: " . $stmt->error . "');</script>";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Create Account</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet"> <style>
        body {
        background-color: #D3D3D3;
            font-family: 'Inter', sans-serif;
        }
        .card {
            border: none;
            border-radius: 2rem;
            background-color: #2a2a2a;
            box-shadow: 0 8px 20px rgba(0,0,0,0.08);
        }
 
        .form-label {
            font-weight: 600;
        }
        .container {
            min-height: 100vh;
        }
        .btn-primary {
            border-radius: 50px;
        }
    </style>
</head>
<body>
    <div class="container d-flex justify-content-center align-items-center">
        <div class="card p-4 p-md-5 my-5 w-100" style="max-width: 600px;">
            <h2 class="text-center text-white mb-4 fw-bold">Create an Account</h2>
            <form method="POST" enctype="multipart/form-data">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="username" class="form-label" style="color:white">Username</label>
                        <input type="text" class="form-control" name="username" required>
                    </div>
                    <div class="col-md-6">
                        <label for="email" class="form-label" style="color:white">Email</label>
                        <input type="email" class="form-control" name="email" required>
                    </div>
                    <div class="col-md-6">
                        <label for="password" class="form-label" style="color:white">Password</label>
                        <input type="password" class="form-control" name="password" required>
                    </div>
                    <div class="col-md-6">
                        <label for="number" class="form-label" style="color:white">Phone Number</label>
                        <input type="text" class="form-control" name="number" required>
                    </div>
                    <div class="col-12">
                        <label for="address" class="form-label" style="color:white">Address</label>
                        <textarea class="form-control" name="address" rows="2" required></textarea>
                    </div>
                    <div class="col-md-6">
                        <label for="image" class="form-label" style="color:white">Profile Image</label>
                        <input type="file" class="form-control" name="image" accept="image/*">
                    </div>
                    <div class="col-md-6">
                        <label for="user_type" class="form-label" style="color:white">User Type</label>
                        <select class="form-select" name="user_type" required>
                            <option value="user" selected>User</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                </div>
                <div class="g-recaptcha mt-3" data-sitekey="6LeYi4gqAAAAACfjk9Hv39L3WOJqG9Plfii3Dmw5"></div>
                <div class="d-grid mt-4">
                    <button type="submit" class="btn btn-primary py-2">Register</button>
                    
                </div>
                        <p class="text-center text-white mt-3">Already have anaccount? <a href="index.php">Login</a></p>

            </form>
        </div>
    </div>
</body>
</html>
