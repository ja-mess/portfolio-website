<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php'; // Ensure your path to autoload.php is correct

include("config.php");

if (!isset($_GET['email'])) {
    echo "Invalid access.";
    exit();
}

$email = $_GET['email'];
$message = "";
$redirect = "";

// Set OTP expiry if not already set (3 minutes)
if (!isset($_SESSION['otp_expiry'])) {
    $_SESSION['otp_expiry'] = time() + 180; // OTP expires in 3 minutes
}

// Function to send OTP
function sendOTP($email, $otp) {
    $mail = new PHPMailer(true);
    try {
        // SMTP settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'jamesbryancaberamos11@gmail.com';  // Your Gmail address
        $mail->Password = 'qfso bsol rnot oxtk'; // <-- Must be a valid App Password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Sender and recipient
        $mail->setFrom('jamesbryancaberamos11@gmail.com', 'Access Control System');
        $mail->addAddress($email);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Your OTP for Login';
        $mail->Body = '
        <html><body>
        <div style="font-family: Arial; background-color: #f4f4f4; padding: 20px;">
            <div style="background: #fff; padding: 30px; border-radius: 8px;">
                <h2>Your OTP for Login</h2>
                <p>Use the following OTP to continue:</p>
                <div style="font-size: 24px; font-weight: bold; color: #2e6da4; background: #e7f3fe; padding: 10px; border-radius: 5px; text-align: center;">' . $otp . '</div>
                <p>This OTP is valid for 5 minutes.</p>
                <p>Access Control System</p>
            </div>
        </div>
        </body></html>';

        $mail->send();
    } catch (Exception $e) {
        echo "Error sending OTP: {$mail->ErrorInfo}";
    }
}

// Handle OTP Resend
if (isset($_POST['action']) && $_POST['action'] === 'resend_otp') {
    $newOtp = rand(100000, 999999);
    $_SESSION['otp'] = $newOtp;
    $_SESSION['otp_expiry'] = time() + 180; // Reset expiry

    // Send OTP email
    sendOTP($email, $newOtp);

    $message = "OTP resent successfully. Please check your email.";
}

// OTP Verification
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['action'])) {
    $enteredOtp = $_POST['otp'] ?? '';
    $storedOtp = $_SESSION['otp'] ?? '';
    $otpExpired = time() > ($_SESSION['otp_expiry'] ?? 0);

    if ($otpExpired) {
        $message = "OTP expired. Please request a new one.";
    } elseif ($enteredOtp == $storedOtp) {
        $sql = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            $_SESSION["user"] = $user["username"];
            $_SESSION["user_type"] = $user["user_type"];
            $_SESSION["user_id"] = $user["id"];

            logActivity($user['id'], $user['username'], 'Login Successful');
            unset($_SESSION['otp']);
            unset($_SESSION['otp_expiry']);

            if ($user["user_type"] === 'admin') {
                $message = "Admin login successful!";
                $redirect = "admin_dashboard.php";
            } else {
                $message = "Login successful!";
                $redirect = "user_page.php";
            }
        } else {
            $message = "User not found!";
        }

        $stmt->close();
    } else {
        $message = "Invalid OTP. Please try again.";
    }
}

function getUserIP() {
    foreach (['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $key) {
        if (!empty($_SERVER[$key])) {
            $ipList = explode(',', $_SERVER[$key]);
            foreach ($ipList as $ip) {
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
            }
        }
    }
    return 'UNKNOWN';
}

function logActivity($userId, $username, $action) {
    global $conn;
    $ip = getUserIP();
    $sql = "INSERT INTO activity_logs (user_id, username, action, ip_address) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isss", $userId, $username, $action, $ip);
    $stmt->execute();
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Verify OTP</title>
  <style>
    body { 
        background-color: #D3D3D3;
        color: #333; /* Dark text color for readability */
        font-family: 'Segoe UI', sans-serif;
        min-height: 100vh;
    }

    .otp-container {
        max-width: 400px;
        margin: 100px auto;
        background: #ffffff; /* White background */
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        text-align: center;
        color: #000;
    }

    input {
        padding: 12px;
        width: 80%;
        margin: 12px 0;
        border-radius: 4px;
        border: 1px solid #ddd;
        background-color: #f7f7f7; /* Light background for input fields */
    }

    button {
        padding: 12px 24px;
        background-color: #007bff; /* Blue button */
        color: white;
        border: none;
        border-radius: 50px;
        width: 85%;
    }

    button:hover {
        background-color: #0056b3; /* Darker blue when hovered */
    }

    .footer {
        margin-top: 15px;
        font-size: 14px;
        color: #6c757d;
    }

    #countdown {
        margin-top: 10px;
        font-weight: bold;
        color: #007bff; /* Blue countdown */
    }
</style>

</head>
<body>
    <div class="otp-container">
        <h2>Verify Your OTP</h2>
        
        <?php if (!empty($message)): ?>
            <div style="color: red; margin-bottom: 20px;"><?php echo $message; ?></div>
        <?php endif; ?>

        <form method="POST">
            <input type="text" name="otp" placeholder="Enter OTP" required />
            <button type="submit">Verify OTP</button>
        </form>

        <form method="POST" style="margin-top: 20px;">
            <input type="hidden" name="action" value="resend_otp" />
            <button type="submit">Resend OTP</button>
        </form>

        <div class="footer">
            <p>If you did not request this OTP, please ignore this message.</p>
        </div>

        <div id="countdown"></div> <!-- Countdown display -->
    </div>

    <?php if (!empty($redirect)): ?>
        <script>
            window.location.href = "<?php echo $redirect; ?>";
        </script>
    <?php endif; ?>

    <script>
        // Countdown Timer for OTP Expiry
        var expiryTime = <?php echo $_SESSION['otp_expiry']; ?>;
        var countdownElement = document.getElementById('countdown');

        function updateCountdown() {
            var currentTime = Math.floor(Date.now() / 1000); // Current time in seconds
            var timeLeft = expiryTime - currentTime;

            if (timeLeft <= 0) {
                countdownElement.innerHTML = "OTP has expired.";
                return;
            }

            var minutes = Math.floor(timeLeft / 60);
            var seconds = timeLeft % 60;
            countdownElement.innerHTML = "Time left: " + minutes + "m " + seconds + "s";
        }

        setInterval(updateCountdown, 1000);
    </script>
</body>
</html>
