<?php
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    $user_type = $_POST["user_type"];
    $number = $_POST["number"];
    $address = $_POST["address"];

    // Handle image upload
    $imageName = "";
    if (isset($_FILES["image"]) && $_FILES["image"]["error"] === 0) {
        $targetDir = "uploads/";
        $imageName = uniqid() . "_" . basename($_FILES["image"]["name"]);
        $targetFile = $targetDir . $imageName;
        move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile);
    }

    if ($user_type != 'admin' && $user_type != 'user') {
        echo "<script>alert('Invalid user type!');</script>";
        exit();
    }

    // Check if email already exists
    $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        echo "<script>alert('Email is already registered. Please use another.'); window.history.back();</script>";
        exit();
    }
    $check->close();

    // Insert new user
    $sql = "INSERT INTO users (username, email, password, user_type, number, address, image) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssss", $username, $email, $password, $user_type, $number, $address, $imageName);

    if ($stmt->execute()) {
        echo "<script>alert('Registered successfully!'); window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('Error: " . $stmt->error . "');</script>";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <div class="card shadow-lg">
        <h2 class="text-center">Create Account</h2>
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="username">Username</label>
                <input type="text" class="form-control" name="username" required>
            </div>
            <div class="mb-3">
                <label for="email">Email</label>
                <input type="email" class="form-control" name="email" required>
            </div>
            <div class="mb-3">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password" required>
            </div>
            <div class="mb-3">
                <label for="number">Phone Number</label>
                <input type="text" class="form-control" name="number" required>
            </div>
            <div class="mb-3">
                <label for="address">Address</label>
                <textarea class="form-control" name="address" rows="2" required></textarea>
            </div>
            <div class="mb-3">
                <label for="image">Profile Image</label>
                <input type="file" class="form-control" name="image" accept="image/*">
            </div>
            <div class="mb-3">
                <label for="user_type">User Type</label>
                <select class="form-control" name="user_type" required>
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary w-100">Register</button>
        </form>
        <p class="text-center mt-3">Already have an account? <a href="index.php">Login</a></p>
    </div>
</body>
</html>
