<?php
session_start();
include("config.php");
if (!isset($_SESSION["user"]) || !isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$sql = "SELECT * FROM products";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>User Dashboard</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #1a1a1a;
            color: #f0f0f0;
            font-family: 'Segoe UI', sans-serif;
        }

        .sidebar {
            height: 100vh;
            background-color: #111;
            padding: 20px;
            position: fixed;
            width: 250px;
        }

        .sidebar h2 {
            color: #00adb5;
            margin-bottom: 30px;
        }

        .sidebar a, .sidebar form button {
            display: block;
            color: #ddd;
            padding: 10px 15px;
            margin-bottom: 10px;
            background-color: #1f1f1f;
            border: none;
            text-align: left;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.2s ease;
        }

        .sidebar a:hover, .sidebar form button:hover {
            background-color: #00adb5;
            color: #fff;
        }

        .content {
            margin-left: 270px;
            padding: 40px 20px;
        }

        .card {
            background-color: #2a2a2a;
            border: none;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            
        }
        .card-text{
            color:white;
        }

        .card:hover {
            transform: scale(1.02);
            box-shadow: 0 4px 20px rgba(0, 173, 181, 0.4);
        }

        .card-title {
            color: #00adb5;
            font-size: 1.2rem;
            font-weight: 600;
        }

        .btn-success {
            background-color: #00adb5;
            border: none;
        }

        .btn-success:hover {
            background-color: #019aa1;
        }

        h3 {
            color: #00adb5;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h2>MyShop</h2>
    <a href="user_page.php">Home</a>
    <a href="profile.php">Profile</a>
    <form action="logout.php" method="post">
        <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($_SESSION['user_id']); ?>">
        <button type="submit">Logout</button>
    </form>
</div>

<!-- Content -->
<div class="content">
    <h2>Welcome, <?php echo htmlspecialchars($_SESSION["user"]); ?>!</h2>
    <p>User ID: <?php echo htmlspecialchars($_SESSION['user_id']); ?></p>

    <h3 class="mt-5" id="products">Shop Now</h3>
    <div class="row mt-4">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='col-lg-3 col-md-4 col-sm-6 mb-4'>
                        <div class='card h-100'>
                            <img src='uploads/" . htmlspecialchars($row['image']) . "' class='card-img-top' style='height: 200px; object-fit: cover;'>
                            <div class='card-body d-flex flex-column justify-content-between'>
                                <h5 class='card-title'>" . htmlspecialchars($row['name']) . "</h5>
                                <p class='card-text text-muted' style='font-size: 0.9rem;'>" . htmlspecialchars($row['description']) . "</p>
                                <p class='card-text'><strong>$" . number_format($row['price'], 2) . "</strong></p>
                                <form action='checkout.php' method='post'>
                                    <input type='hidden' name='product_id' value='" . htmlspecialchars($row['id']) . "'>
                                    <div class='d-grid'>
                                        <button type='submit' class='btn btn-success'>Buy Now</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>";
            }
        } else {
            echo "<p class='text-center'>No products available.</p>";
        }
        ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
x