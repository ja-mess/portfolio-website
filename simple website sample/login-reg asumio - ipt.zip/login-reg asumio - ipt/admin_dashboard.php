<?php
session_start();

// Check if user is logged in and is admin
if (!isset($_SESSION['user']) || $_SESSION['user_type'] !== 'admin') {
    echo "<script>alert('Access Denied! Admins only.'); window.location.href='index.php';</script>";
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="d-flex justify-content-center align-items-center vh-100 bg-light">
    <div class="container text-center">
        <h1 class="mb-4">Welcome, Admin <?php echo htmlspecialchars($_SESSION['user']); ?>!</h1>
        
        <div class="row g-4 justify-content-center">
            <div class="col-md-3">
                <a href="manage_users.php" class="btn btn-primary btn-lg shadow w-100">Manage Users</a>
            </div>
            <div class="col-md-3">
                <a href="manage_products.php" class="btn btn-secondary btn-lg shadow w-100">Manage Products</a>
            </div>
            <div class="col-md-3">
                <a href="activity_log.php" class="btn btn-info btn-lg shadow w-100">Activity Log</a>
            </div>
            <div class="col-md-3">
                <a href="logout.php" class="btn btn-danger btn-lg shadow w-100">Logout</a>
            </div>
        </div>
    </div>
</body>
</html>

