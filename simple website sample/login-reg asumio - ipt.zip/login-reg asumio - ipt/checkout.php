<?php
session_start();
include("config.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $productId = (int) $_POST['product_id'];

    // Fetch product details
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
    $stmt->close();
} else {
    die("Invalid request.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Checkout</title>
       <link rel="stylesheet" href="styles.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
      
        .checkout-card {
            max-width: 600px;
            margin: 50px auto;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        .product-img {
            height: 250px;
            object-fit: cover;
            border-radius: 8px;
        }
    </style>
</head>
<body>

<div class="container">
    <?php if ($product): ?>
        <div class="card checkout-card p-4 bg-white rounded-4">
            <h2 class="text-center mb-4">Checkout</h2>
            <div class="row">
                <div class="col-md-6">
                    <?php if (!empty($product['image'])): ?>
                        <img src="uploads/<?php echo htmlspecialchars($product['image']); ?>" alt="Product Image" class="img-fluid product-img">
                    <?php else: ?>
                        <div class="bg-secondary text-white text-center py-5 rounded">No Image</div>
                    <?php endif; ?>
                </div>
                <div class="col-md-6">
                    <h4><?php echo htmlspecialchars($product['name']); ?></h4>
                    <p><?php echo htmlspecialchars($product['description']); ?></p>
                    <p class="fw-bold fs-5 text-success">$<?php echo number_format($product['price'], 2); ?></p>
                    
                    <!-- PayPal Button -->
                    <div id="paypal-button-container" class="my-3"></div>

                    <form action="place_order.php" method="post">
    <input type="hidden" name="product_id" value="<?php echo $productId; ?>">
    <input type="hidden" name="payment_method" value="manual"> <!-- You can also use "paypal" if PayPal is chosen -->
    <button type="submit" class="btn btn-primary w-100">Place Order (Manual)</button>
</form>

                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-danger mt-5 text-center">Product not found.</div>
    <?php endif; ?>
</div>

<!-- PayPal SDK -->
<script src="https://www.paypal.com/sdk/js?client-id=Ac4Plr-JR9LZ3_tADnoR6aFccccUlo0Ax6Xp8IILopiM67frT-3sUhC0dhObkFPCHj_HKLHQ1Z8jVUAY&currency=USD"></script>

<script>
paypal.Buttons({
    createOrder: function(data, actions) {
        return actions.order.create({
            purchase_units: [{
                description: "<?php echo addslashes($product['name']); ?>",
                amount: {
                    value: "<?php echo number_format($product['price'], 2, '.', ''); ?>"
                }
            }]
        });
    },
    onApprove: function(data, actions) {
        return actions.order.capture().then(function(details) {
            alert('Transaction completed by ' + details.payer.name.given_name);

            // Optional: Send order details to the server
            fetch('place_order.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'product_id=<?php echo $productId; ?>&paypal_order_id=' + data.orderID
            }).then(() => {
                window.location.href = 'thank_you.php';
            });
        });
    }
}).render('#paypal-button-container');
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
