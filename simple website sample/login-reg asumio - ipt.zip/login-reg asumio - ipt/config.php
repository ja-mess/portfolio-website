<?php
$host = "localhost";
$user = "root"; // Update if needed
$pass = ""; // Update if needed
$dbname = "ipt_ky";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
