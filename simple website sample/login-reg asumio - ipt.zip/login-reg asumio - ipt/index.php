<?php
include("config.php");
session_start();

// Load PHPMailer for email sending
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

// Function to send OTP to user email
// Function to send OTP to user email
function sendOTP($email, $otp) {
    $mail = new PHPMailer(true);
    try {
        // SMTP Configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'jamesbryancaberamos11@gmail.com';
        $mail->Password = 'rhdi jsvq kzgb woak'; // Use an app password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Email Content
        $mail->setFrom('jamesbryancaberamos11@gmail.com', 'Access Control System');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = 'Your OTP for Login';

        // Stylish HTML email body
        $mail->Body = '
        <html>
        <head>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #f4f4f4;
                    color: #333;
                    padding: 20px;
                }
                .container {
                    background-color: #ffffff;
                    padding: 30px;
                    border-radius: 8px;
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                }
                .header {
                    font-size: 24px;
                    color: #FF69B4;
                    text-align: center;
                    margin-bottom: 20px;
                }
                .otp {
                    font-size: 20px;
                    font-weight: bold;
                    color: #FF1493;
                    text-align: center;
                    padding: 15px;
                    background-color: #e7f3fe;
                    border-radius: 5px;
                    margin: 20px 0;
                }
                .footer {
                    text-align: center;
                    font-size: 14px;
                    color: #777;
                    margin-top: 30px;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    Your OTP for Login
                </div>
                <p>Hello,</p>
                <p>We received a request to log in to your account. Use the following OTP to proceed:</p>
                <div class="otp">
                    ' . $otp . '
                </div>
                <p>This OTP is valid for 5 minutes. If you did not request this login, please ignore this email.</p>
                <div class="footer">
                    <p>Access Control System</p>
                    <p>For any questions, contact support.</p>
                </div>
            </div>
        </body>
        </html>';

        // Send the email
        $mail->send();

        // Store OTP in session for verification
        $_SESSION['otp'] = $otp;

        // Redirect to verify page with email parameter
        header("Location: verify.php?email=" . urlencode($email));
        exit();
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}


// Example usage: Generate OTP and send to the user
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['email'])) {
    $email = $_POST['email'];
    $otp = rand(100000, 999999); // Generate OTP
    sendOTP($email, $otp);
}

// Function to log activity
function logActivity($userId, $username, $action) {
    global $conn;
    $sql = "INSERT INTO activity_logs (user_id, username, action) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $userId, $username, $action);
    $stmt->execute();
    $stmt->close();
}

// CSRF Token for form protection
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['email'], $_POST['password'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die("CSRF token validation failed!");
    }

    $email = $_POST["email"];
    $password = $_POST["password"];

    // Use prepared statement to fetch user data
    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user["password"])) {
            session_regenerate_id(true); // Prevent session fixation
            $_SESSION["user"] = $user["username"];
            $_SESSION["user_type"] = $user["user_type"];
            $_SESSION["user_id"] = $user["id"];

            // Log successful login
            logActivity($user['id'], $user['username'], 'Login Successful');

            if ($user["user_type"] === 'admin') {
                echo "<script>alert('Admin login successful!'); window.location.href='admin_dashboard.php';</script>";
            } else {
                echo "<script>alert('Login successful!'); window.location.href='user_page.php';</script>";
            }
        } else {
            // Log failed password attempt
            logActivity($user['id'], $user['username'], 'Failed Login - Incorrect Password');
            echo "<script>alert('Incorrect password!');</script>";
        }
    } else {
        // Log failed login due to unknown user
        logActivity(0, $email, 'Failed Login - User Not Found');
        echo "<script>alert('User not found!');</script>";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">

</head>

<style>
        body {
            background: linear-gradient(to right, #f8cdda, #1d2b64);
            color: #fff;
            font-family: 'Segoe UI', sans-serif;
            min-height: 100vh;
        }

        h2, h3 {
            color: #ffe0f0;
        }

        .navbar {
            background-color: #212529;
        }

        .card {
            border: none;
            border-radius: 1rem;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }

        .card-body {
            background-color: #ffffff;
            border-radius: 0 0 1rem 1rem;
            color: #333;
        }

        .card-title {
            font-weight: 600;
            font-size: 1.1rem;
        }

        .card-text {
            font-size: 0.95rem;
        }

        .btn-success {
            background-color: #28a745;
            border: none;
        }

        .btn-success:hover {
            background-color: #218838;
        }

        .container h3 {
            color: #ffc0cb;
            font-weight: 600;
        }

        .text-center.text-white {
            color: #f8f9fa !important;
        }
    </style>
<body class="d-flex justify-content-center align-items-center vh-100">
    <div class="card p-4 shadow-lg" style="width: 400px;">
        <h2 class="text-center text-primary">Login</h2>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
            <div class="mb-3">
                <label>Email</label>
                <input type="email" class="form-control" name="email" required>
            </div>
            <div class="mb-3">
                <label>Password</label>
                <input type="password" class="form-control" name="password" required>
            </div>
            <button class="btn btn-primary w-100" type="submit">Login</button>
        </form>
        <form action="guest_page.php" method="GET" class="mt-2">
            <button class="btn btn-primary w-100">Login as Guest</button>
        </form>
        <p class="text-center mt-3">New user? <a href="register.php">Register</a></p>
    </div>
</body>
</html>
