<?php
include("config.php");
session_start();

// Function to log activity
function logActivity($userId, $username, $action) {
    global $conn;
    $sql = "INSERT INTO activity_logs (user_id, username, action) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("iss", $userId, $username, $action);
        if (!$stmt->execute()) {
            error_log("Failed to log activity: " . $stmt->error);
        }
        $stmt->close();
    } else {
        error_log("Failed to prepare statement: " . $conn->error);
    }
}

// Check if the user is logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user'])) {
    echo "You are not logged in. Please log in first.";
    exit;
}

// Log the logout action
logActivity($_SESSION['user_id'], $_SESSION['user'], "Logout");

// Clear session data
session_unset();
session_destroy();

// Redirect to index.php
header("Location: index.php");
exit();
?>
