<?php
session_start();
include("config.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    // Ensure the user is logged in
    if (!isset($_SESSION['user_id'])) {
        die("Please login to place an order.");
    }

    // Get the user_id from session and product_id from the POST request
    $userId = $_SESSION['user_id'];
    $productId = (int) $_POST['product_id'];

    // Fetch product details from the database
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    // If product is not found, redirect to the product page or display an error
    if (!$product) {
        die("Product not found.");
    }

    // Collect order details
    $totalAmount = $product['price'];  // Assuming the price is in the product record
    $shippingAddress = 'Shipping Address';  // You can replace this with user address from session or form
    $paymentMethod = isset($_POST['payment_method']) ? $_POST['payment_method'] : 'manual';
    $orderStatus = 'pending';

    // If PayPal was used, get the PayPal order ID
    $paypalOrderId = isset($_POST['paypal_order_id']) ? $_POST['paypal_order_id'] : null;

    // Insert order into the database
    $stmt = $conn->prepare("INSERT INTO orders (user_id, product_id, order_date, status, total_amount, shipping_address, payment_method, paypal_order_id) 
                            VALUES (?, ?, NOW(), ?, ?, ?, ?, ?)");
    $stmt->bind_param("iissdss", $userId, $productId, $orderStatus, $totalAmount, $shippingAddress, $paymentMethod, $paypalOrderId);
    
    if ($stmt->execute()) {
        echo "<script>alert('Order placed successfully!'); window.location.href='thank_you.php';</script>";
    } else {
        echo "<script>alert('Error: " . $stmt->error . "');</script>";
    }

    $stmt->close();
} else {
    echo "<script>alert('Invalid request.');</script>";
}
?>
