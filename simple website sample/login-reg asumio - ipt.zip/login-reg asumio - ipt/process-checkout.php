<?php
session_start();
include("config.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_id = intval($_POST['product_id']);
    $user_id = intval($_POST['user_id']);

    // Optional: Save to "orders" table or mark as purchased

    // Redirect or confirm
    echo "<div class='alert alert-success'>Purchase successful for product ID: $product_id</div>";
    echo "<a href='user.php'>Go Back</a>";
} else {
    header("Location: user_page.php");
}
