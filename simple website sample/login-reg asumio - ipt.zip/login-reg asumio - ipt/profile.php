<?php
session_start();
include("config.php");

if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('You must be logged in to view your profile.'); window.location.href='login.php';</script>";
    exit();
}

$userId = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT username, email, number, address, image, user_type FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>My Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">

    <style>
        .profile-img {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 50%;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="user_page.php">MyShop</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <div class="ms-auto d-flex gap-2">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="profile.php" class="btn btn-outline-light">Profile</a>
                    <form action="logout.php" method="post" style="display:inline;">
                        <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($_SESSION['user_id']); ?>">
                        <button type="submit" class="btn btn-danger">Logout</button>
                    </form>
                <?php else: ?>
                    <a href="login.php" class="btn btn-primary">Login</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>


<div class="container mt-5">
    <div class="card mx-auto p-4 shadow" style="max-width: 500px;">
        <h3 class="text-center text-primary mb-3">My Profile</h3>
        <div class="text-center mb-4">
            <?php if (!empty($user['image'])): ?>
                <img src="uploads/<?php echo htmlspecialchars($user['image']); ?>" class="profile-img" alt="Profile Image">
            <?php else: ?>
                <div class="bg-secondary text-white profile-img d-inline-flex align-items-center justify-content-center">No Image</div>
            <?php endif; ?>
        </div>
        <ul class="list-group">
            <li class="list-group-item"><strong>Username:</strong> <?php echo htmlspecialchars($user['username']); ?></li>
            <li class="list-group-item"><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></li>
            <li class="list-group-item"><strong>Phone:</strong> <?php echo htmlspecialchars($user['number']); ?></li>
            <li class="list-group-item"><strong>Address:</strong> <?php echo htmlspecialchars($user['address']); ?></li>
            <li class="list-group-item"><strong>User Type:</strong> <?php echo htmlspecialchars($user['user_type']); ?></li>
        </ul>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
