<?php
session_start();
include("config.php");  // Ensure this includes your DB connection

// Check if email and OTP are set
if (!isset($_GET['email'])) {
    echo "Invalid access.";
    exit();
}

$email = $_GET['email'];

// Check if OTP is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $enteredOtp = $_POST['otp'] ?? '';
    $storedOtp = $_SESSION['otp'] ?? '';

    if ($enteredOtp == $storedOtp) {
        // OTP Verified successfully, proceed to login

        // Fetch user details from the database
        $sql = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            // Automatically log the user in if OTP is correct
            $_SESSION["user"] = $user["username"];
            $_SESSION["user_type"] = $user["user_type"];
            $_SESSION["user_id"] = $user["id"];

            // Log successful login
            logActivity($user['id'], $user['username'], 'Login Successful');

            // Redirect based on user type
            if ($user["user_type"] === 'admin') {
                echo "<script>alert('Admin login successful!'); window.location.href='admin_dashboard.php';</script>";
            } else {
                echo "<script>alert('Login successful!'); window.location.href='user_page.php';</script>";
            }
        } else {
            // Handle the case when the user is not found in the database
            echo "<script>alert('User not found!');</script>";
        }

        $stmt->close();
        unset($_SESSION['otp']); // Clear OTP after successful verification
    } else {
        echo "Invalid OTP. Please try again.";
    }
}

// Function to log activity
function logActivity($userId, $username, $action) {
    global $conn;
    $sql = "INSERT INTO activity_logs (user_id, username, action) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $userId, $username, $action);
    $stmt->execute();
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Verify OTP</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0px 4px 12px rgba(141, 34, 87, 0.1);
            width: 400px;
        }

        h2 {
            text-align: center;
            color: #FF1493;
        }

        label {
            font-size: 16px;
            font-weight: bold;
            color: #333;
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-bottom: 20px;
            font-size: 16px;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color:rgb(220, 83, 179);
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #FF69B4;
        }

        .footer {
            text-align: center;
            font-size: 14px;
            color: #777;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Verify Your OTP</h2>
        <form method="post">
            <label for="otp">Enter OTP:</label>
            <input type="text" id="otp" name="otp" required />
            <button type="submit">Verify OTP</button>
        </form>
        <div class="footer">
            <p>If you did not request this OTP, please ignore this message.</p>
        </div>
    </div>
</body>
</html>
