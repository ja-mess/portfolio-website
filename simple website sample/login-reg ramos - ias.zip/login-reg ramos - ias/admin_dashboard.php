<?php
session_start();

// Check if user is logged in and is admin
if (!isset($_SESSION['user']) || $_SESSION['user_type'] !== 'admin') {
    echo "<script>alert('Access Denied! Admins only.'); window.location.href='index.php';</script>";
    exit();
}

// Fetch total number of users (or any data you need)
include("config.php");
$sql = "SELECT COUNT(*) AS user_count FROM users WHERE user_type = 'user'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$userCount = $row['user_count'];

// Example data for a graph (replace with actual query data as needed)
$productsSql = "SELECT COUNT(*) AS product_count FROM products";
$productsResult = $conn->query($productsSql);
$productsRow = $productsResult->fetch_assoc();
$productCount = $productsRow['product_count'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Custom Sidebar Styling */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 250px;
            background-color: #343a40;
            color: white;
            padding-top: 20px;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
        }
        .sidebar a:hover {
            background-color: #007bff;
        }
        .content {
            margin-left: 270px;
            padding: 20px;
        }
        .content h1 {
            margin-bottom: 30px;
        }
        .chart-container {
            width: 100%;
            max-width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body class="bg-light">
    <!-- Sidebar -->
    <?php include('admin_sidebar.php'); ?>             

    <!-- Main Content -->
    <div class="content">
        <h1>Welcome, Admin <?php echo htmlspecialchars($_SESSION['user']); ?>!</h1>

        <!-- Graph Section -->
        <div class="chart-container">
            <canvas id="dashboardChart"></canvas>
        </div>

      
        </div>
    </div>

    <script>
        // Data for the chart
        var ctx = document.getElementById('dashboardChart').getContext('2d');
        var dashboardChart = new Chart(ctx, {
            type: 'bar', // You can change the chart type (e.g., 'line', 'pie', 'radar')
            data: {
                labels: ['Users', 'Products'], // Labels for the chart
                datasets: [{
                    label: 'Count',
                    data: [<?php echo $userCount; ?>, <?php echo $productCount; ?>], // Data from PHP variables
                    backgroundColor: ['#007bff', '#28a745'],
                    borderColor: ['#0056b3', '#218838'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
