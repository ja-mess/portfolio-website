<?php
include("config.php");
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

// Function to send OTP
function sendOTP($email, $otp) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'jamesbryancaberamos11@gmail.com';
        $mail->Password = 'qfso bsol rnot oxtk'; // App password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('jamesbryancaberamos11@gmail.com', 'Access Control System');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = 'Your OTP for Login';
        $mail->Body = '
        <html><body>
        <div style="font-family: Arial; background-color: #f4f4f4; padding: 20px;">
            <div style="background: #fff; padding: 30px; border-radius: 8px;">
                <h2>Your OTP for Login</h2>
                <p>Use the following OTP to continue:</p>
                <div style="font-size: 24px; font-weight: bold; color: #2e6da4; background: #e7f3fe; padding: 10px; border-radius: 5px; text-align: center;">' . $otp . '</div>
                <p>This OTP is valid for 5 minutes.</p>
                <p>Access Control System</p>
            </div>
        </div>
        </body></html>';

        $mail->send();
        $_SESSION['otp'] = $otp;
        return true;
    } catch (Exception $e) {
        error_log("Mailer Error: " . $mail->ErrorInfo);
        return "Failed to send OTP. Please try again.";
    }
}

// Get the user's real IP address
function getUserIP() {
    $headers = [
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'HTTP_X_REAL_IP',
        'REMOTE_ADDR'
    ];

    foreach ($headers as $key) {
        if (!empty($_SERVER[$key])) {
            $ipList = explode(',', $_SERVER[$key]);
            foreach ($ipList as $ip) {
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
    }

    return 'UNKNOWN';
}

// Log user activity
function logActivity($userId, $username, $action) {
    global $conn;

    $ipAddress = getUserIP();

    $sql = "INSERT INTO activity_logs (user_id, username, action, ip_address) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("isss", $userId, $username, $action, $ipAddress);
        $stmt->execute();
        $stmt->close();
    } else {
        error_log("logActivity DB error: " . $conn->error);
    }
}

// CSRF token generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Initialize error
$error = "";

// Handle login
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['email'], $_POST['password'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $error = "CSRF token validation failed!";
    } else {
        $email = $_POST["email"];
        $password = $_POST["password"];

        $sql = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $user = $result->fetch_assoc();

            if ($user['is_locked']) {
                $error = "Your account is locked due to multiple failed login attempts.";
            } elseif (password_verify($password, $user["password"])) {
                session_regenerate_id(true);
                $_SESSION["user"] = $user["username"];
                $_SESSION["user_type"] = $user["user_type"];
                $_SESSION["user_id"] = $user["id"];

                // Reset failed attempts
                $conn->query("UPDATE users SET failed_attempts = 0, is_locked = 0 WHERE id = " . $user["id"]);

                logActivity($user['id'], $user['username'], 'Login Successful');

                // Set OTP session flag before sending
                $_SESSION['otp_allowed'] = true;

                // Generate and send OTP
                $otp = rand(100000, 999999);
                $otpResult = sendOTP($email, $otp);

                if ($otpResult === true) {
                    header("Location: verify.php?email=" . urlencode($email));
                    exit();
                } else {
                    $error = $otpResult;
                }
            } else {
                // Increment failed attempts
                $conn->query("UPDATE users SET failed_attempts = failed_attempts + 1 WHERE id = " . $user["id"]);
                $conn->query("UPDATE users SET is_locked = 1 WHERE id = " . $user["id"] . " AND failed_attempts >= 3");

                logActivity($user['id'], $user['username'], 'Failed Login - Incorrect Password');
                $error = "Incorrect password!";
            }
        } else {
            logActivity(0, $email, 'Failed Login - Email not found');
            $error = "No account found with this email!";
        }

        $stmt->close();
    }
}
?>


<!-- Login Form -->
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<style>
    body{
        background-color: #D3D3D3;
    }
.card {
            background-color: #2a2a2a;
            border: none;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            
        }
        

        </style>
<body class="d-flex justify-content-center align-items-center vh-100">
    <div class="card p-4 shadow-lg" style="width: 400px;">
        <!-- Picture at the top of the login box -->
     <!--   <div class="text-center mb-4">
            <img src="UBLOGO.jpg" alt="Login Image" class="img-fluid rounded-circle" style="width: 100px; height: 100px;">
        </div> -->

        <h2 class="text-center text-primary">Login</h2>

        <?php
        // Check if there's a flash message for logout
        if (isset($_SESSION['logout_message'])) {
            // Show the success message using SweetAlert
            echo "<script>
                    Swal.fire({
                        title: 'Success!',
                        text: '" . $_SESSION['logout_message'] . "',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    });
                  </script>";

            // Unset the flash message after displaying it
            unset($_SESSION['logout_message']);
        }
        ?>
        
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
            <div class="mb-3">
                <label style="color:white">Email</label>
                <input type="email" class="form-control" name="email" required>
            </div>
            <div class="mb-3">
                <label style="color:white">Password</label>
                <input type="password" class="form-control" name="password" required>
            </div>
            <button class="btn btn-primary w-100" type="submit">Login</button>
        </form>

        <form action="guest_page.php" method="GET" class="mt-2">
            <button class="btn btn-guest text-white w-100">Login as Guest</button>
        </form>
        <p class="text-center text-white mt-3">New user? <a href="register.php">Register</a></p>
    </div>
</body>
</html>