<?php
include("config.php");
session_start();

// Helper to get real client IP address
function getUserIP() {
    $headers = [
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'HTTP_X_REAL_IP',
        'REMOTE_ADDR'
    ];

    foreach ($headers as $key) {
        if (!empty($_SERVER[$key])) {
            $ipList = explode(',', $_SERVER[$key]);
            foreach ($ipList as $ip) {
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
    }

    return 'UNKNOWN';
}

// Function to log activity with IP address
function logActivity($userId, $username, $action) {
    global $conn;
    $ipAddress = getUserIP(); // Get the real IP address of the user

    // SQL query to log the activity in the database
    $sql = "INSERT INTO activity_logs (user_id, username, action, ip_address) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("isss", $userId, $username, $action, $ipAddress); // Bind parameters
        if (!$stmt->execute()) {
            error_log("Failed to log activity: " . $stmt->error); // Log error if failed to execute
        }
        $stmt->close();
    } else {
        error_log("Failed to prepare statement: " . $conn->error); // Log error if failed to prepare statement
    }
}

// Check if the user is logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user'])) {
    echo "You are not logged in. Please log in first.";
    exit;
}

// Log the logout activity
logActivity($_SESSION['user_id'], $_SESSION['user'], "Logout");

// Clear session data
session_unset();
session_destroy();

// Set a flash message to show a successful logout
session_start();
$_SESSION['logout_message'] = "You have been successfully logged out.";

// Redirect to index.php after logging out
header("Location: index.php");
exit();
?>
