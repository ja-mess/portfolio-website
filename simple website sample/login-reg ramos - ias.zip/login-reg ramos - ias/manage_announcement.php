<?php
session_start();
include("config.php");

$message = "";
$editing = false;
$editData = [];

// Handle Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM announcements WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $message = "✅ Announcement deleted.";
    } else {
        $message = "❌ Delete failed.";
    }
    $stmt->close();
}

// Handle Edit Load
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $conn->prepare("SELECT * FROM announcements WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows) {
        $editData = $result->fetch_assoc();
        $editing = true;
    }
    $stmt->close();
}

// Handle Create or Update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'] ?? null;
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $start_date = $_POST['start_date'] ?? null;
    $end_date = $_POST['end_date'] ?? null;
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    $image = null;

    // Upload image
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (in_array($_FILES['image']['type'], $allowedTypes)) {
            $dir = "uploads/";
            if (!file_exists($dir)) mkdir($dir, 0777, true);
            $filename = time() . "_" . preg_replace("/[^A-Za-z0-9_.]/", "_", basename($_FILES["image"]["name"]));
            $path = $dir . $filename;
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $path)) {
                $image = $path;
            }
        } else {
            $message = "❌ Invalid image type.";
        }
    }

    if (empty($message)) {
        if ($id) {
            // Update
            if ($image) {
                $stmt = $conn->prepare("UPDATE announcements SET title=?, content=?, image=?, start_date=?, end_date=?, is_active=?, updated_at=NOW() WHERE id=?");
                $stmt->bind_param("sssssii", $title, $content, $image, $start_date, $end_date, $is_active, $id);
            } else {
                $stmt = $conn->prepare("UPDATE announcements SET title=?, content=?, start_date=?, end_date=?, is_active=?, updated_at=NOW() WHERE id=?");
                $stmt->bind_param("ssssii", $title, $content, $start_date, $end_date, $is_active, $id);
            }
            if ($stmt->execute()) {
                $message = "✅ Announcement updated.";
            } else {
                $message = "❌ Update failed.";
            }
            $stmt->close();
        } else {
            // Insert
            $stmt = $conn->prepare("INSERT INTO announcements (title, content, image, start_date, end_date, is_active, created_at, updated_at)
                                    VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())");
            $stmt->bind_param("sssssi", $title, $content, $image, $start_date, $end_date, $is_active);
            if ($stmt->execute()) {
                $message = "✅ Announcement created.";
            } else {
                $message = "❌ Creation failed.";
            }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Announcements</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>

    <style>
        body { font-family: Arial, sans-serif; background: #f9f9f9; }
        .container-fluid {
            margin-left: 270px;
            padding: 20px;
            background: #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-top: 20px;
        }
        h2, h3 { color: #333; }
        .message {
            background: #e0ffe0;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #b2d8b2;
            color: #2d662d;
            border-radius: 5px;
        }
        form {
            background: #fcfcfc;
            padding: 20px;
            border-radius: 5px;
            border: 1px solid #ddd;
            margin-bottom: 30px;
        }
        label { font-weight: bold; }
        input[type="text"], input[type="date"], textarea {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="file"] {
            margin-bottom: 15px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 16px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        table.dataTable thead th {
            background-color: #f2f2f2;
        }
        img { max-height: 60px; }
    </style>
</head>
<body>

<?php include('admin_sidebar.php'); ?>

<div class="container-fluid">
    <h2><?= $editing ? 'Edit' : 'Create' ?> Announcement</h2>

    <?php if (!empty($message)): ?>
        <div class="message"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <?php if ($editing): ?>
            <input type="hidden" name="id" value="<?= $editData['id'] ?>">
        <?php endif; ?>

        <label>Title:</label>
        <input type="text" name="title" value="<?= $editing ? htmlspecialchars($editData['title']) : '' ?>" required>

        <label>Content:</label>
        <textarea name="content" rows="4" required><?= $editing ? htmlspecialchars($editData['content']) : '' ?></textarea>

        <label>Image:</label><br>
        <?php if ($editing && $editData['image']): ?>
            <img src="<?= $editData['image'] ?>" width="100"><br><br>
        <?php endif; ?>
        <input type="file" name="image">

        <label>Start Date:</label>
        <input type="date" name="start_date" value="<?= $editing ? $editData['start_date'] : '' ?>">

        <label>End Date:</label>
        <input type="date" name="end_date" value="<?= $editing ? $editData['end_date'] : '' ?>">

        <label>Is Active:</label>
        <input type="checkbox" name="is_active" <?= $editing && $editData['is_active'] ? 'checked' : (!$editing ? 'checked' : '') ?>><br><br>

        <button type="submit"><?= $editing ? 'Update' : 'Submit' ?></button>
    </form>

    <hr>
    <h3>All Announcements</h3>
    <table id="userListTable" class="display">
        <thead>
            <tr>
                <th>ID</th><th>Title</th><th>Active</th><th>Start</th><th>End</th><th>Image</th><th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $result = $conn->query("SELECT * FROM announcements ORDER BY id DESC");
        while ($row = $result->fetch_assoc()):
        ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['title']) ?></td>
                <td><?= $row['is_active'] ? '✅' : '❌' ?></td>
                <td><?= $row['start_date'] ?></td>
                <td><?= $row['end_date'] ?></td>
                <td><?php if ($row['image']): ?><img src="<?= $row['image'] ?>" width="60"><?php endif; ?></td>
                <td>
                    <a href="?edit=<?= $row['id'] ?>">Edit</a> |
                    <a href="?delete=<?= $row['id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>

<script>
    // Initialize DataTables
    $(document).ready(function() {
        $('#userListTable').DataTable({
            "paging": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "lengthMenu": [5, 10, 25, 50],
            "pageLength": 5
        });
    });
</script>

</body>
</html>
