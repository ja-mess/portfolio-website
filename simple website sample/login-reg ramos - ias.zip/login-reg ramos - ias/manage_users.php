<?php
session_start();
include("config.php");

// Check if user is logged in and is admin
if (!isset($_SESSION['user']) || $_SESSION['user_type'] !== 'admin') {
    echo "<script>alert('Access Denied! Admins only.'); window.location.href='index.php';</script>";
    exit();
}

// Initialize variables
$username = "";
$email = "";
$password = "";
$userId = "";
$userType = "user"; // Default to "user" type
$isEdit = false;

// Handle add or edit user form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $userType = $_POST['user_type']; // Get the user type from the form
    
    if (isset($_POST['userId']) && !empty($_POST['userId'])) {
        // Edit user
        $userId = $_POST['userId'];
        $sql = "UPDATE users SET username=?, email=?, user_type=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $username, $email, $userType, $userId);
    } else {
        // Add user
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (username, email, password, user_type) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $username, $email, $password, $userType);
    }
    
    if ($stmt->execute()) {
        echo "<script>alert('Operation successful!'); window.location.href='manage_users.php';</script>";
    } else {
        echo "<script>alert('Error occurred!'); window.location.href='manage_users.php';</script>";
    }
}

// Handle edit action
if (isset($_GET['edit'])) {
    $userId = $_GET['edit'];
    $sql = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $username = $result['username'];
    $email = $result['email'];
    $userType = $result['user_type']; // Get user type
    $isEdit = true;
}

// Handle delete action
if (isset($_GET['delete'])) {
    $userId = $_GET['delete'];
    $deleteSql = "DELETE FROM users WHERE id = ?";
    $stmt = $conn->prepare($deleteSql);
    $stmt->bind_param("i", $userId);
    if ($stmt->execute()) {
        echo "<script>alert('User deleted successfully!'); window.location.href='manage_users.php';</script>";
    } else {
        echo "<script>alert('Error deleting user!'); window.location.href='manage_users.php';</script>";
    }
}

// Fetch only users with user_type = 'user'
$sql = "SELECT * FROM users WHERE user_type = 'user'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Users</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
</head>

<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <?php include('admin_sidebar.php'); ?>          

        <!-- Main Content -->
        <div class="container-fluid" style="margin-left: 270px; padding: 20px;">
            <h1 class="text-center mb-4">Manage Users</h1>

            <!-- Add/Edit User Form -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <h2><?php echo $isEdit ? 'Edit User' : 'Add User'; ?></h2>
                    <form method="POST">
                        <input type="hidden" name="userId" value="<?php echo htmlspecialchars($userId); ?>">
                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" name="username" class="form-control" value="<?php echo htmlspecialchars($username); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>" required>
                        </div>
                        <!-- User Type Dropdown -->
                        <div class="mb-3">
                            <label class="form-label">User Type</label>
                            <select name="user_type" class="form-control" required>
                                <option value="user" <?php echo $userType === 'user' ? 'selected' : ''; ?>>User</option>
                                <option value="admin" <?php echo $userType === 'admin' ? 'selected' : ''; ?>>Admin</option>
                            </select>
                        </div>
                        <?php if (!$isEdit): ?>
                            <div class="mb-3">
                                <label class="form-label">Password</label>
                                <input type="password" name="password" class="form-control" required>
                            </div>
                        <?php endif; ?>
                        <button type="submit" class="btn btn-success"><?php echo $isEdit ? 'Update User' : 'Add User'; ?></button>
                    </form>
                </div>

                <!-- User List -->
                <div class="col-md-6">
                    <h2>User List</h2>
                    <table id="userListTable" class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>User Type</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo $row['username']; ?></td>
                                    <td><?php echo $row['email']; ?></td>
                                    <td><?php echo $row['user_type']; ?></td>
                                    <td>
                                        <a href="manage_users.php?edit=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                        <a href="manage_users.php?delete=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');">Delete</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery and DataTables JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>

    <script>
        // Initialize DataTables
        $(document).ready(function() {
            $('#userListTable').DataTable({
                "paging": true,      // Enable pagination
                "searching": true,   // Enable search
                "ordering": true,    // Enable sorting
                "info": true,        // Show table information
                "lengthMenu": [5, 10, 25, 50], // Set the number of entries per page
                "pageLength": 5      // Default number of records per page
            });
        });
    </script>
</body>
</html>
