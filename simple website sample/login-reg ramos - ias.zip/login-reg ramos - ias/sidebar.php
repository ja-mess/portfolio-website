<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Portal</title>
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Navbar */
        .navbar {
            background-color: #111;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .navbar h2 {
            color: #00adb5;
            font-size: 1.5rem;
        }

        .navbar a {
            color: #ddd;
            padding: 10px 15px;
            text-decoration: none;
            font-size: 1rem;
            border-radius: 5px;
            margin: 0 10px;
            transition: background 0.2s ease;
        }

        .navbar a:hover {
            background-color: #00adb5;
            color: #fff;
        }

        .navbar #logout-btn {
            background-color: #1f1f1f;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            color: #ddd;
            font-size: 1rem;
            border-radius: 5px;
            transition: background 0.2s ease;
        }

        .navbar #logout-btn:hover {
            background-color: #00adb5;
            color: #fff;
        }

        /* Main Content */
        .content {
            margin-top: 80px;
            padding: 20px;
            background-color: #f5f5f5;
            min-height: 100vh;
        }

        .footer {
            margin-top: 20px;
            font-size: 14px;
            text-align: center;
            color: #6c757d;
        }

    </style>
</head>
<body>

    <!-- Navbar -->
    <div class="navbar">
        <h2>Student Portal</h2>
        <div>
            <a href="user_page.php">My Subjects</a>
            <a href="announcements.php">Announcements</a>
            <a href="profile.php">Profile</a>
             <form id="logout-form" action="logout.php" method="post" style="display: none;">
        <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($_SESSION['user_id']); ?>">
    </form>
            <button type="button" id="logout-btn">Logout</button>
        </div>
    </div>



    <!-- SweetAlert2 CDN -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        document.getElementById('logout-btn').addEventListener('click', function (e) {
            e.preventDefault();

            Swal.fire({
                title: 'Are you sure?',
                text: "You are about to log out.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, logout'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Assuming you have a logout form to handle the backend
                    document.getElementById('logout-form').submit();
                }
            });
        });
    </script>
</body>
</html>
