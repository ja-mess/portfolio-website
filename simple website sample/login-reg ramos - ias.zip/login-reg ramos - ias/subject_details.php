<?php
session_start();
include("config.php");
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('You must be logged in to view  this page.'); window.location.href='index.php';</script>";
    exit();
}

if (!isset($_GET['subject_id'])) {
    die("Subject ID is required.");
}

$subject_id = intval($_GET['subject_id']);

// Get subject details (optional, for display)
$subjectSql = "SELECT * FROM subjects WHERE id = $subject_id";
$subject = $conn->query($subjectSql)->fetch_assoc();

// Get activities and projects
$activitiesSql = "SELECT * FROM activities WHERE subject_id = $subject_id";
$projectsSql = "SELECT * FROM projects WHERE subject_id = $subject_id";

$activities = $conn->query($activitiesSql);
$projects = $conn->query($projectsSql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Subject Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #1a1a1a;
            color: #f0f0f0;
        }
        .section-title {
            color: #00adb5;
        }
        .card {
            background-color: #2a2a2a;
            margin-bottom: 20px;
            border: none;
        }
        .card-title {
            color: #00adb5;
        }
        .card-text {
            color: #ccc;
        }
        .btn-back {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
        }
        .btn-back:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <a href="javascript:history.back()" class="btn btn-back mb-4">Back</a>

    <h2 class="section-title"><?= htmlspecialchars($subject['subject_name']) ?></h2>
    <p><?= htmlspecialchars($subject['description']) ?></p>
    <p><strong>Instructor:</strong> <?= htmlspecialchars($subject['instructor']) ?></p>

    <hr>

    <h4 class="section-title">Activities</h4>
    <?php if ($activities->num_rows > 0): ?>
        <?php while ($activity = $activities->fetch_assoc()): ?>
            <div class="card p-3">
                <h5 class="card-title"><?= htmlspecialchars($activity['title']) ?></h5>
                <p class="card-text"><?= nl2br(htmlspecialchars($activity['description'])) ?></p>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No activities found.</p>
    <?php endif; ?>

    <h4 class="section-title mt-5">Projects</h4>
    <?php if ($projects->num_rows > 0): ?>
        <?php while ($project = $projects->fetch_assoc()): ?>
            <div class="card p-3">
                <h5 class="card-title"><?= htmlspecialchars($project['title']) ?></h5>
                <p class="card-text"><?= nl2br(htmlspecialchars($project['description'])) ?></p>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No projects found.</p>
    <?php endif; ?>
</div>

</body>
</html>
