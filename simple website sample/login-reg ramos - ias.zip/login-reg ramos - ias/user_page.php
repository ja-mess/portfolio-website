<?php
session_start();
include("config.php");

// Rate Limiting Logic
$user_id = $_SESSION['user_id'];
$endpoint = "search_subjects";
$limit = 10;
$time_frame = 30;

// Check the count of requests made in the last minute
$sql = "SELECT COUNT(*) as request_count FROM rate_logs 
        WHERE user_id = ? AND endpoint = ? AND request_time > NOW() - INTERVAL ? SECOND";
$stmt = $conn->prepare($sql);
$stmt->bind_param("isi", $user_id, $endpoint, $time_frame);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

// If limit is reached, show an alert and prevent search
if ($row['request_count'] >= $limit) {
    echo '<div class="alert alert-danger text-center" role="alert">
            Rate limit exceeded. Please wait and try again.
          </div>';
    exit;
}

// Log the request
$sql = "INSERT INTO rate_logs (user_id, endpoint) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $user_id, $endpoint);
$stmt->execute();

// Handle search query
$search = isset($_GET['search']) ? $_GET['search'] : '';
$sql = "SELECT * FROM subjects WHERE subject_name LIKE ?";
$stmt = $conn->prepare($sql);
$likeSearch = "%" . $search . "%";
$stmt->bind_param("s", $likeSearch);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Student Portal</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

 <style>
        body {
        background-color: #D3D3D3;
            color: #333333;
            font-family: 'Segoe UI', sans-serif;
        }

        .content {
            margin-left: 270px;
            padding: 40px 20px;
        }

        .card {
            background-color: #2a2a2a;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .card:hover {
            transform: scale(1.02);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .card-title {
            color:rgb(255, 255, 255);
            font-size: 1.2rem;
            font-weight: 600;
        }

        .card-text {
            color:rgb(255, 255, 255);
        }

        .btn-info {
            background-color: #4CAF50;
            border: none;
            color: white;
        }

        .btn-info:hover {
            background-color: #45a049;
        }

        h2, h3 {
            color: #333333;
        }

        input[type="text"] {
            border-radius: 8px;
            border: 1px solid #ccc;
            padding: 8px;
            width: 250px;
        }

        button[type="submit"] {
            background-color: #6c757d;
            border: none;
            color: white;
            padding: 8px 16px;
            border-radius: 8px;
        }

        button[type="submit"]:hover {
            background-color: #5a6268;
        }

        p.text-center.text-muted {
            color: #888888;
        }
    </style> 
<body>

<?php include('sidebar.php'); ?>

<div class="content">
    <h2>Welcome, <?php echo htmlspecialchars($_SESSION["user"]); ?>!</h2>
    <p>Student ID: <?php echo htmlspecialchars($_SESSION['user_id']); ?></p>

    <h3 class="mt-5">Enrolled Subjects</h3>
    <form method="get" class="mb-4 d-flex">
        <input type="text" name="search" class="form-control me-2" placeholder="Search subjects..." value="<?php echo htmlspecialchars($search); ?>">
        <button type="submit" class="btn btn-secondary">Search</button>
    </form>

    <div class="row mt-4">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='col-lg-4 col-md-6 col-sm-12 mb-4'>
                        <div class='card h-100'>
                            <div class='card-body d-flex flex-column justify-content-between'>
                                <h5 class='card-title'>" . htmlspecialchars($row['subject_name']) . "</h5>
                                <p class='card-text'>" . htmlspecialchars($row['description']) . "</p>
                                <p class='card-text'><strong>Instructor:</strong> " . htmlspecialchars($row['instructor']) . "</p>
                                <form action='subject_details.php' method='get'>
                                    <input type='hidden' name='subject_id' value='" . htmlspecialchars($row['id']) . "'>
                                    <div class='d-grid'>
                                        <button type='submit' class='btn btn-info'>View Details</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>";
            }
        } else {
            echo "<p class='text-center text-muted'>No subjects found.</p>";
        }
        ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>      