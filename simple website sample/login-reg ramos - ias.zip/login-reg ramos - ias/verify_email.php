<?php
// verify_email.php
include("config.php");
session_start();

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Validate token
    $stmt = $conn->prepare("SELECT id, email, reset_token_expiration FROM users WHERE reset_token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $expiry = new DateTime($user['reset_token_expiration']);
        $now = new DateTime();

        if ($now < $expiry) {
            // Token is valid, show the password reset form
            if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['password'], $_POST['confirm_password'])) {
                $password = $_POST['password'];
                $confirm_password = $_POST['confirm_password'];

                if ($password === $confirm_password) {
                    // Hash the password
                    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

                    // Update the password and clear the token
                    $update = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_token_expiration = NULL WHERE id = ?");
                    $update->bind_param("si", $hashed_password, $user['id']);
                    
                    if ($update->execute()) {
                        echo "<script>alert('Password reset successfully.'); window.location.href = 'index.php';</script>";
                    } else {
                        echo "<script>alert('Failed to update password. Please try again.');</script>";
                    }
                } else {
                    echo "<script>alert('Passwords do not match.');</script>";
                }
            }
        } else {
            echo "<script>alert('This link has expired.'); window.location.href = 'forgot_password.php';</script>";
        }
    } else {
        echo "<script>alert('Invalid token.'); window.location.href = 'forgot_password.php';</script>";
    }
}
?>

<!-- Reset Password Form -->
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Reset Password</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Reset Your Password</h2>
    <form method="POST">
        <div class="mb-3">
            <label>New Password</label>
            <input type="password" class="form-control" name="password" required>
        </div>
        <div class="mb-3">
            <label>Confirm New Password</label>
            <input type="password" class="form-control" name="confirm_password" required>
        </div>
        <button type="submit" class="btn btn-primary">Reset Password</button>
    </form>
</div>
</body>
</html>
