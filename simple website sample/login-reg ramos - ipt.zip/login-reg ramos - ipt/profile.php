<?php
session_start();
include("config.php");

if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('You must be logged in to view your profile.'); window.location.href='login.php';</script>";
    exit();
}

$userId = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT username, email, number, address, image, user_type FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>My Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">

    <style>
        .profile-img {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 50%;
        }

        body {
            background-color: #1a1a1a;
            color: #f0f0f0;
            font-family: 'Segoe UI', sans-serif;
        }

        .sidebar {
            height: 100vh;
            background-color: #111;
            padding: 20px;
            position: fixed;
            width: 250px;
        }

        .sidebar h2 {
            color: #00adb5;
            margin-bottom: 30px;
        }

        .sidebar a, .sidebar form button {
            display: block;
            color: #ddd;
            padding: 10px 15px;
            margin-bottom: 10px;
            background-color: #1f1f1f;
            border: none;
            text-align: left;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.2s ease;
        }

        .sidebar a:hover, .sidebar form button:hover {
            background-color: #00adb5;
            color: #fff;
        }

        .content {
            margin-left: 270px;
            padding: 40px 20px;
        }

        .card {
            background-color: #2a2a2a;
            border: none;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            
        }
        .card-text{
            color:white;
        }

        .card:hover {
            transform: scale(1.02);
            box-shadow: 0 4px 20px rgba(0, 173, 181, 0.4);
        }

        .card-title {
            color: #00adb5;
            font-size: 1.2rem;
            font-weight: 600;
        }

        .btn-success {
            background-color: #00adb5;
            border: none;
        }

        .btn-success:hover {
            background-color: #019aa1;
        }

        h3 {
            color: #00adb5;
        }
    </style>
</head>
<body>
<div class="sidebar">
    <h2>MyShop</h2>
    <a href="user_page.php">Home</a>
    <a href="profile.php">Profile</a>
    <form action="logout.php" method="post">
        <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($_SESSION['user_id']); ?>">
        <button type="submit">Logout</button>
    </form>
</div>

<div class="container mt-5">
    <div class="card mx-auto p-4 shadow" style="max-width: 500px;">
        <h3 class="text-center text-primary mb-3">My Profile</h3>
        <div class="text-center mb-4">
            <?php if (!empty($user['image'])): ?>
                <img src="uploads/<?php echo htmlspecialchars($user['image']); ?>" class="profile-img" alt="Profile Image">
            <?php else: ?>
                <div class="bg-secondary text-white profile-img d-inline-flex align-items-center justify-content-center">No Image</div>
            <?php endif; ?>
        </div>
        <ul class="list-group">
            <li class="list-group-item"><strong>Username:</strong> <?php echo htmlspecialchars($user['username']); ?></li>
            <li class="list-group-item"><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></li>
            <li class="list-group-item"><strong>Phone:</strong> <?php echo htmlspecialchars($user['number']); ?></li>
            <li class="list-group-item"><strong>Address:</strong> <?php echo htmlspecialchars($user['address']); ?></li>
            <li class="list-group-item"><strong>User Type:</strong> <?php echo htmlspecialchars($user['user_type']); ?></li>
        </ul>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
