<?php
session_start();
include("config.php");

if (!isset($_GET['email'])) {
    echo "Invalid access.";
    exit();
}

$email = $_GET['email'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $enteredOtp = $_POST['otp'] ?? '';
    $storedOtp = $_SESSION['otp'] ?? '';

    if ($enteredOtp == $storedOtp) {
        $sql = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            $_SESSION["user"] = $user["username"];
            $_SESSION["user_type"] = $user["user_type"];
            $_SESSION["user_id"] = $user["id"];

            logActivity($user['id'], $user['username'], 'Login Successful');

            unset($_SESSION['otp']); // clear OTP after successful login

            if ($user["user_type"] === 'admin') {
                echo "<script>alert('Admin login successful!'); window.location.href='admin_dashboard.php';</script>";
            } else {
                echo "<script>alert('Login successful!'); window.location.href='user_page.php';</script>";
            }
        } else {
            echo "<script>alert('User not found!');</script>";
        }

        $stmt->close();
    } else {
        echo "<script>alert('Invalid OTP. Please try again.');</script>";
    }
}

function logActivity($userId, $username, $action) {
    global $conn;
    $sql = "INSERT INTO activity_logs (user_id, username, action) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $userId, $username, $action);
    $stmt->execute();
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Verify OTP</title>

</head>
<body>
    <div class="otp-container">
        <h2>Verify Your OTP</h2>
        <form method="POST">
            <label for="otp">Enter OTP:</label>
            <input type="text" id="otp" name="otp" required />
            <button type="submit">Verify OTP</button>
        </form>
        <div class="footer">
            <p>If you did not request this OTP, please ignore this message.</p>
        </div>
    </div>
</body>
</html>
